// module.exports = {
//     mode: "development",

//     module: {
//         rules: [
//             {
//                 test: /\.(js|jsx)$/,
//                 exclude: /node_modules/,
//                 use: {
//                     loader: "babel-loader",
//                     options: {
//                         presets: ["@babel/preset-env", "@babel/preset-react"]
//                     }
//                 }
//             },
//             {
//                 test: /\.css$/,
//                 use: ["style-loader", "css-loader"]
//             },
//             {
//                 test: /\.(png|jpe?g|gif)$/i, // Load images
//                 use: [
//                     {
//                         loader: "file-loader",
//                         options: {
//                             name: "[path][name].[ext]"
//                         }
//                     }
//                 ]
//             }
//         ]
//     },

//     resolve: {
//         fallback: {
//             // "crypto": require.resolve("crypto-browserify"),
//             "crypto": false,
//             "vm": require.resolve("vm-browserify"),
//             "stream": require.resolve("stream-browserify")
//         }
//     }

//     // resolve: {
//     //     fallback: {
//     //         "crypto": false,
//     //         "vm": false,
//     //         "stream": false
//     //     }
//     // }
// };




module.exports = {
    mode: "development",

    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader",
                    options: {
                        presets: ["@babel/preset-env", "@babel/preset-react"]
                    }
                }
            },
            {
                test: /\.css$/,
                use: ["style-loader", "css-loader"]
            },
            {
                test: /\.(png|jpe?g|gif)$/i,
                use: [
                    {
                        loader: "file-loader",
                        options: {
                            name: "[path][name].[ext]"
                        }
                    }
                ]
            }
        ]
    },

    resolve: {
        fallback: {
            "crypto": require.resolve("crypto-browserify"),
            // "crypto": false,
            "stream": require.resolve("stream-browserify"),
            "vm": require.resolve("vm-browserify")
        }
    }
};