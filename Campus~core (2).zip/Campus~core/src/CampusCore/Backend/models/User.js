const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true },
    // Field to store the reset token for password recovery
    resetToken: { type: String, default: null },
    // Field to store the expiration time of the reset token
    resetTokenExpires: { type: Date, default: null }
  },
  { timestamps: true } // Automatically adds createdAt and updatedAt fields
);

const User = mongoose.model("User", userSchema);

module.exports = User;
