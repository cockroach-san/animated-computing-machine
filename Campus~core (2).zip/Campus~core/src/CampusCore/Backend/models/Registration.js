const Registration = require('../models/Registration');

/**
 * This middleware verifies that the registration record being accessed
 * (for example, when updating or deleting) belongs to the authenticated user.
 */
module.exports.verifyRegistrationOwnership = async (req, res, next) => {
  try {
    // Get the registration ID from the route parameters
    const { id } = req.params;
    const registration = await Registration.findById(id);

    // If the registration is not found, return a 404 response
    if (!registration) {
      return res.status(404).json({ error: 'Registration not found' });
    }

    // Ensure the registration belongs to the user stored in req.user (set by your auth middleware)
    if (registration.userId.toString() !== req.user.id) {
      return res.status(403).json({
        error: 'Access denied. You are not allowed to access this registration.',
      });
    }

    // Attach registration to the request for downstream middleware/handlers if needed
    req.registration = registration;
    next();
  } catch (error) {
    console.error('Error verifying registration ownership:', error);
    res.status(500).json({ error: 'Server error during registration ownership check' });
  }
};
