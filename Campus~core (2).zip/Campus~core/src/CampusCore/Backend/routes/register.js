const express = require("express");
const argon2 = require("argon2");  
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const router = express.Router();

router.post("/", async (req, res) => {
  try {
    // Destructure username, email, and password from the request body
    const { username, email, password } = req.body;

    // Validate that all required fields are provided
    if (!username || !email || !password) {
      return res.status(400).json({ error: "Username, email, and password are required." });
    }

    // Check if a user with the provided email exists
    let existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "A user with that email already exists." });
    }

    // Check if a user with the provided username exists
    existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ error: "Username is already taken." });
    }

    // Hash the provided password using Argon2 for security
    const hashedPassword = await argon2.hash(password);

    // Create a new user with the provided fields
    const newUser = new User({ username, email, password: hashedPassword });
    await newUser.save();

    // Generate a JWT token for the new user
    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    // Respond with a success message and the token
    res.status(201).json({
      message: "Signup successful",
      token,
      user: { username: newUser.username, email: newUser.email }
    });
  } catch (error) {
    console.error("Error during signup:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
