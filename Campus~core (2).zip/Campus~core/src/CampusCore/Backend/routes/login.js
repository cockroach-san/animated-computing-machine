const express = require("express");
const argon2 = require("argon2");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit"); // ✅ Prevent excessive login attempts
const User = require("../models/User");
const router = express.Router();

// ✅ Rate limiter to prevent brute-force attacks
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // Limit each IP to 5 login requests per windowMs
    message: "Too many login attempts. Please try again later.",
});

router.post("/", loginLimiter, async (req, res) => {
    const { email, password } = req.body || {}; // ✅ Prevents destructuring error

    if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required." });
    }

    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(401).json({ message: "Invalid credentials." });

        // ✅ Verify password using Argon2
        const isValid = await argon2.verify(user.password, password);
        if (!isValid) return res.status(401).json({ message: "Invalid credentials." });

        // ✅ Generate secure JWT Token with HS256 encryption
        const token = jwt.sign(
            { id: user._id, email: user.email, role: user.role }, // Include role for frontend logic
            process.env.JWT_SECRET,
            { algorithm: "HS256", expiresIn: "1h" } // ✅ Stronger security
        );

        res.json({ token, role: user.role }); // ✅ Send role for role-based routing
    } catch (error) {
        console.error("Login Error:", error); // ✅ Logs error for debugging
        res.status(500).json({ message: "Server error. Please try again later." });
    }
});

module.exports = router;