const express = require('express');
const Event = require('../models/Registration'); // Ensure your registration model is correctly defined
const router = express.Router();

/**
 * @route   POST /registration
 * @desc    Create a new event registration entry
 * @access  Public
 */
router.post('/registration', async (req, res) => {
  try {
    // Create a new event registration from the request body data
    const newEvent = new Event(req.body);
    await newEvent.save();

    // Respond with the created event registration data
    res.status(201).json(newEvent);
  } catch (error) {
    console.error('Error creating event registration:', error);
    res.status(500).json({ error: 'Failed to create event registration' });
  }
});

module.exports = router;
