const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  // Get the token directly from the Authorization header (no Bearer prefix expected)
  const token = req.header('Authorization');

  if (!token) {
    return res
      .status(401)
      .json({ error: 'Access denied, no token provided' });
  }

  try {
    // Verify the token using your secret key from the environment variables
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};
