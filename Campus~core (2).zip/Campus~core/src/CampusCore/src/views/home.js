import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom'; // To handle hash-based navigation

import Hero from '../components/hero';
import Features1 from '../components/features1';
import CTA from '../components/cta';
import Features2 from '../components/features2';
import Steps from '../components/steps';
import Testimonial from '../components/testimonial';
import Contact from '../components/contact'; // Ensure Contact is imported correctly
import Footer from '../components/footer';
import './home.css';

const Home = () => {
  const location = useLocation(); // React hook to access URL location

  useEffect(() => {
    if (location.hash) {
      const element = document.querySelector(location.hash);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' }); // Enable smooth scrolling
      }
    }
  }, [location]);

  return (
    <div className="home-container">
      <Hero
        action1="Login"
        action2="Register Now"
        heading1="Welcome to Campus~Core"
        content1="Manage all campus events, special lectures, and more with ease. Register students and streamline event organization."
      />
      <Features1 feature1Title="Scheduled Highlights" feature2Title="Special Lecture" />
      <CTA heading1="Register for Special Lecture" />
      <Features2
        feature1Title="Event Listings"
        feature3Title="One-Click Join"
        feature1Description="A streamlined directory of forthcoming events, including detailed information such as dates, times, and locations, presented in a clear and organized manner."
        feature3Description='Bold and vibrant "Join the Action!" buttons for instant registration, no hassle, no delays.'
      />
      <Steps />
      <Testimonial
        content1="The student registration system made it so easy for me to sign up for campus events. I highly recommend it to all my classmates!"
        heading1="What People Say"
        author1Name="Sam"
        author2Name="Jane"
        author3Name="Aniket"
        author4Name="Emily"
      />
      {/* Add id="contact" to Contact */}
      <Contact />
      <Footer logoSrc="src/student registration system-react  2/src/viewslogoo.png" />
    </div>
  );
};

export default Home;