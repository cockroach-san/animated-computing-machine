import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App'; // Assuming App.js is in the src folder
import './style.css'; // Assuming style.css is in the src folder

const root = createRoot(document.getElementById('root'));
root.render(<App />);