import React, { useState } from "react";
import axios from "axios";
import "./Register.css";

const Register = () => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    repeatPassword: "",
    termsAccepted: false,
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
    setError(""); // Clear errors on change
  };

  const handleSignUp = async (e) => {
    e.preventDefault();

    // Validation checks
    if (!formData.username || !formData.email || !formData.password || !formData.repeatPassword) {
      setError("Please fill in all fields.");
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    if (formData.password !== formData.repeatPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (!formData.termsAccepted) {
      setError("Please accept the terms and conditions.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/auth/register", formData);
      setSuccess("Account created successfully!");
      setError(""); // Clear any previous errors
    } catch (err) {
      setError(err.response?.data?.error || "Registration failed.");
    }
  };

  return (
    <div className="register-page">
      <div className="register-container">
        <h1 className="register-title">CREATE ACCOUNT</h1>
        {error && <p className="error-message">{error}</p>}
        {success && <p className="success-message">{success}</p>}
        <form onSubmit={handleSignUp}>
          <input
            type="text"
            name="username"
            placeholder="Full Name"
            className="register-input"
            onChange={handleChange}
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            className="register-input"
            onChange={handleChange}
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            className="register-input"
            onChange={handleChange}
          />
          <input
            type="password"
            name="repeatPassword"
            placeholder="Repeat Password"
            className="register-input"
            onChange={handleChange}
          />
          <div className="register-checkbox">
            <input
              type="checkbox"
              id="terms"
              name="termsAccepted"
              onChange={handleChange}
            />
            <label htmlFor="terms" className="register-checkbox-label">
              I agree to all statements in <a href="#">Terms of Service</a>
            </label>
          </div>
          <button type="submit" className="register-button">
            SIGN UP
          </button>
        </form>
        <p className="register-login-link">
          Already have an account? <a href="/login">Login here</a>
        </p>
      </div>
    </div>
  );
};

export default Register;