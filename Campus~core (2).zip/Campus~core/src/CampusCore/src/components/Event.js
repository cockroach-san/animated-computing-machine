import React, { Fragment } from 'react'

import { Helmet } from 'react-helmet'

import Pricing141 from '../components/pricing141'
// import Logos81 from '../components/logos81'
import Features161 from '../components/features161'
import FAQ141 from '../components/faq141'
import Footer21 from '../components/footer21'
import './Event.css'

const Page = (props) => {
  return (
    <div className="page-container">
      <Helmet>
        <title>Page - Spotless Hungry Crocodile</title>
        <meta property="og:title" content="Page - Spotless Hungry Crocodile" />
      </Helmet>
      <Pricing141
        plan2Action1={
          <Fragment>
            <span className="page-text20">Get started</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="page-text21">Events</span>
          </Fragment>
        }
        plan1Feature31={
          <Fragment>
            <span className="page-text33">
              Receive notifications for upcoming workshops
            </span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="page-text34">Join Our Events</span>
          </Fragment>
        }
        plan3Action1={
          <Fragment>
            <span className="page-text35">Get started</span>
          </Fragment>
        }
        rootClassName="pricing141root-class-name"
      ></Pricing141>
      <Features161
        feature3Title={
          <Fragment>
            <span className="page-text38">Stay Updated</span>
          </Fragment>
        }
        feature1Description={
          <Fragment>
            <span className="page-text39">
              Easily register for campus events with just a few clicks.
            </span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="page-text40">Key Features</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="page-text41">
              Explore upcoming events, lectures, and workshops on Campus~Core.
            </span>
          </Fragment>
        }
        feature2Title={
          <Fragment>
            <span className="page-text42">Manage Registrations</span>
          </Fragment>
        }
        feature2Description={
          <Fragment>
            <span className="page-text43">
              Effortlessly manage your event registrations in one place.
            </span>
          </Fragment>
        }
        feature1Title={
          <Fragment>
            <span className="page-text44">Event Registration</span>
          </Fragment>
        }
        feature3Description={
          <Fragment>
            <span className="page-text45">
              Receive timely updates on all activities happening on campus.
            </span>
          </Fragment>
        }
        slogan1={
          <Fragment>
            <span className="page-text46">
              Simplify your campus event experience with our registration
              system.
            </span>
          </Fragment>
        }
      ></Features161>
      <FAQ141
        action1={
          <Fragment>
            <span className="page-text47">Contact</span>
          </Fragment>
        }
        faq5Question={
          <Fragment>
            <span className="page-text48">
              How can I provide feedback about an event I attended?
            </span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="page-text49">
            If your question isn’t covered here, feel free to contact the campus events team at support@campusevents.com. You can also explore the campus website or connect with us on social media for more information.

              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </Fragment>
        }
        faq4Question={
          <Fragment>
            <span className="page-text50">
              Are there any fees for registering for campus events?
            </span>
          </Fragment>
        }
        faq2Question={
          <Fragment>
            <span className="page-text51">
              Can I cancel my event registration?
            </span>
          </Fragment>
        }
        action2={
          <Fragment>
            <span className="page-text52">Email us</span>
          </Fragment>
        }
        faq3Question={
          <Fragment>
            <span className="page-text53">
              How will I receive updates about upcoming events?
            </span>
          </Fragment>
        }
        heading2={
          <Fragment>
            <span className="page-text54">Still have a question?</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="page-text55">FAQs</span>
          </Fragment>
        }
        faq1Question={
          <Fragment>
            <span className="page-text56">
              How can I register for campus events?
            </span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="page-text57">
              
            </span>
          </Fragment>
        }
      ></FAQ141>
      <Footer21
        column2Title={
          <Fragment>
            <span className="page-text58"></span>
          </Fragment>
        }
        termsLink={
          <Fragment>
            <span className="page-text59"></span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="page-text60">Subscribe</span>
          </Fragment>
        }
        link1={
          <Fragment>
            <span className="page-text61">Home</span>
          </Fragment>
        }
        link10={
          <Fragment>
            <span className="page-text62"></span>
          </Fragment>
        }
        link2={
          <Fragment>
            <span className="page-text63">Events</span>
          </Fragment>
        }
        link4={
          <Fragment>
            <span className="page-text64"></span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="page-text65">
              Stay connected with us on social media for the latest updates and
              news.
            </span>
          </Fragment>
        }
        cookiesLink={
          <Fragment>
            <span className="page-text66"></span>
          </Fragment>
        }
        link6={
          <Fragment>
            <span className="page-text67"></span>
          </Fragment>
        }
        link7={
          <Fragment>
            <span className="page-text68"></span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="page-text69">
              For any inquiries or feedback, feel free to reach out to us via
              email or phone.
            </span>
          </Fragment>
        }
        column1Title={
          <Fragment>
            <span className="page-text70">Quick Links</span>
          </Fragment>
        }
        privacyLink={
          <Fragment>
            <span className="page-text71"></span>
          </Fragment>
        }
        link8={
          <Fragment>
            <span className="page-text72"></span>
          </Fragment>
        }
        link5={
          <Fragment>
            <span className="page-text73"></span>
          </Fragment>
        }
        link3={
          <Fragment>
            <span className="page-text74">About Us</span>
          </Fragment>
        }
        link9={
          <Fragment>
            <span className="page-text75"></span>
          </Fragment>
        }
      ></Footer21>
    </div>
  )
}

export default Page
