import React, { Fragment } from 'react'

import { Helmet } from 'react-helmet'


import Hero71 from './hero71'
import Team5 from './team5'
import Features18 from './features18'
import Testimonial2 from './testimonial2'
import Contact111 from './contact111'
import Footer51 from './footer51'
import './about.css'

const About = (props) => {
  return (
    <div className="about-container">
      <Helmet>
        <title>About - Spotless Hungry Crocodile</title>
        <meta property="og:title" content="About - Spotless Hungry Crocodile" />
      </Helmet>
      
      <Hero71
        heading1={
          <Fragment>
            <span className="about-text23">Welcome to Campus~Core</span>
          </Fragment>
        }
        action1={
          <Fragment>
            <a href="/register" className="team5-text36" style={{ textDecoration: "none", color: "white" }}>Register Now</a>
          </Fragment>
        }
        action2={
          <Fragment>
            <a href="/login" className="team5-text36" style={{ textDecoration: "none", color: "red" }}>Login</a>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="about-text26">
              Easily register for campus events, special lectures, workshops,
              and social gatherings with just a few clicks!
            </span>
          </Fragment>
        }
      ></Hero71>
      <Team5
        member4={
          <Fragment>
            <span className="about-text27">Sarah Lee</span>
          </Fragment>
        }
        member4Content={
          <Fragment>
            <span className="about-text28">
              Sarah is a detail-oriented finance expert who manages the budget
              for various events, ensuring financial transparency and
              accountability.
            </span>
          </Fragment>
        }
        member2Job={
          <Fragment>
            <span className="about-text29">Vice President of Events</span>
          </Fragment>
        }
        member1={
          <Fragment>
            <span className="about-text30">John Doe</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="about-text31">Meet Our Team</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="about-text32">
              Our team of dedicated student leaders works tirelessly to create a
              vibrant campus community through exciting events and engaging
              activities.
            </span>
          </Fragment>
        }
        member1Job={
          <Fragment>
            <span className="about-text33">President of Student Council</span>
          </Fragment>
        }
        member4Job={
          <Fragment>
            <span className="about-text34">Treasurer</span>
          </Fragment>
        }
        member3Job={
          <Fragment>
            <span className="about-text35">Head of Marketing</span>
          </Fragment>
        }
        member3={
          <Fragment>
            <span className="about-text36">Alex Johnson</span>
          </Fragment>
        }
        actionContent={
          <Fragment>
            <a href="/event" className="team5-text36" style={{ textDecoration: "none", color: "white" }}>Get involved in our Events</a>
          </Fragment>
        }
        member2={
          <Fragment>
            <span className="about-text38">Jane Smith</span>
          </Fragment>
        }
        member3Content={
          <Fragment>
            <span className="about-text39">
              Alex is a strategic thinker with a flair for promoting campus
              events effectively, reaching out to a wide audience and increasing
              student engagement.
            </span>
          </Fragment>
        }
        member1Content={
          <Fragment>
            <span className="about-text40">
              John is a dedicated student leader who is passionate about
              enhancing campus life and organizing engaging events for fellow
              students.
            </span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="about-text41">
              Join us in shaping the future of campus life by participating in
              our upcoming events and making lasting memories with fellow
              students.
            </span>
          </Fragment>
        }
        member2Content={
          <Fragment>
            <span className="about-text42">
              Jane is a creative event planner who brings innovative ideas to
              campus activities, ensuring memorable experiences for all
              participants.
            </span>
          </Fragment>
        }
      ></Team5>
      <Features18
        feature1Slogan={
          <Fragment>
            <span className="about-text43"></span>
          </Fragment>
        }
        feature1Title={
          <Fragment>
            <span className="about-text44">Easy Registration Process</span>
          </Fragment>
        }
        feature1Description={
          <Fragment>
            <span className="about-text45">
              Register for campus events with just a few clicks. Say goodbye to
              long queues and paperwork.
            </span>
          </Fragment>
        }
      ></Features18>
      <Testimonial2
        author1Name={
          <Fragment>
            <span className="about-text46">John Smith</span>
          </Fragment>
        }
        author1Position={
          <Fragment>
            <span className="about-text47">Senior at ABC University</span>
          </Fragment>
        }
        review1={
          <Fragment>
            <span className="about-text48">
              The student registration system made it so easy for me to sign up
              for campus events and workshops. I never miss out on any
              opportunities now!
            </span>
          </Fragment>
        }
      ></Testimonial2>
      <Contact111
        content1={
          <Fragment>
            <span className="about-text49">
              Have questions or need assistance? Feel free to reach out to us.
            </span>
          </Fragment>
        }
        email={
          <Fragment>
            <span className="about-text50">
              info@universitycampusregistration.com
            </span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="about-text51">
              You can also visit us at our campus office during office hours.
            </span>
          </Fragment>
        }
        phone1={
          <Fragment>
            <span className="about-text52">+1-123-456-7890</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="about-text53">Contact Us</span>
          </Fragment>
        }
        address1={
          <Fragment>
            <span className="about-text54">
              123 University Campus, City, State, Zip Code
            </span>
          </Fragment>
        }
        content3={
          <Fragment>
            <span className="about-text55">
              We are here to help you with any inquiries or support you may
              need.
            </span>
          </Fragment>
        }
        content5={
          <Fragment>
            <span className="about-text56">
              Follow us on social media for the latest updates and
              announcements.
            </span>
          </Fragment>
        }
      ></Contact111>
      <Footer51
        link5={
          <Fragment>
            <span className="about-text57"></span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="about-text58">Subscribe Now</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="about-text59">Stay Connected with Us</span>
          </Fragment>
        }
        link1={
          <Fragment>
             <a href="/event" className="about-text60" style={{ textDecoration: "none" }}>Events</a>
          </Fragment>
        }
        privacyLink={
          <Fragment>
            <span className="about-text61">Privacy Policy</span>
          </Fragment>
        }
        link4={
          <Fragment>
             <a href="/" className="about-text62" style={{ textDecoration: "none" }}>Home</a>
          </Fragment>
        }
        termsLink={
          <Fragment>
            <span className="about-text63">Terms and Conditions</span>
          </Fragment>
        }
      ></Footer51>
    </div>
  )
}

export default About


// import './about.css';

// const About = (props) => {
//   return (
//     <div className="about-container">
//       <Helmet>
//         <title>About - Spotless Hungry Crocodile</title>
//         <meta property="og:title" content="About - Spotless Hungry Crocodile" />
//       </Helmet>

//       {/* Navbar */}
//       <Navbar7
//         link2={
//           <Fragment>
//             <span className="about-text10">Events</span>
//           </Fragment>
//         }
//         page3={
//           <Fragment>
//             <span className="about-text11">Page Three</span>
//           </Fragment>
//         }
//         page4Description={
//           <Fragment>
//             <span className="about-text12">Lorem ipsum dolor sit amet consectetur elit</span>
//           </Fragment>
//         }
//         page1={
//           <Fragment>
//             <span className="about-text13">Page One</span>
//           </Fragment>
//         }
//         page2={
//           <Fragment>
//             <span className="about-text14">Page Two</span>
//           </Fragment>
//         }
//         page3Description={
//           <Fragment>
//             <span className="about-text15">Lorem ipsum dolor sit amet consectetur elit</span>
//           </Fragment>
//         }
//         page2Description={
//           <Fragment>
//             <span className="about-text16">Lorem ipsum dolor sit amet consectetur elit</span>
//           </Fragment>
//         }
//         page4={
//           <Fragment>
//             <span className="about-text17">Page Four</span>
//           </Fragment>
//         }
//         link5={
//           <Fragment>
//             <span className="about-text18">Contact Us</span>
//           </Fragment>
//         }
//         link4={
//           <Fragment>
//             <span className="about-text19">Special Lectures</span>
//           </Fragment>
//         }
//         link3={
//           <Fragment>
//             <span className="about-text20">Workshops</span>
//           </Fragment>
//         }
//         page1Description={
//           <Fragment>
//             <span className="about-text21">Lorem ipsum dolor sit amet consectetur elit</span>
//           </Fragment>
//         }
//         link1={
//           <Fragment>
//             <span className="about-text22">Home</span>
//           </Fragment>
//         }
//       ></Navbar7>

//       {/* Hero Section */}
//       <Hero71
//         heading1={
//           <Fragment>
//             <span className="about-text23">Welcome to Campus~Core</span>
//           </Fragment>
//         }
//         action1={
//           <Fragment>
//             <span className="about-text24">Register Now</span>
//           </Fragment>
//         }
//         action2={
//           <Fragment>
//             <span className="about-text25">Login</span>
//           </Fragment>
//         }
//         content1={
//           <Fragment>
//             <span className="about-text26">
//               Easily register for campus events, special lectures, workshops, and social gatherings with just a few clicks!
//             </span>
//           </Fragment>
//         }
//       ></Hero71>

//       {/* Team Section */}
//       <Team5
//         member4={
//           <Fragment>
//             <span className="about-text27">Sarah Lee</span>
//           </Fragment>
//         }
//         member4Content={
//           <Fragment>
//             <span className="about-text28">
//               Sarah is a detail-oriented finance expert who manages the budget for various events, ensuring financial transparency and accountability.
//             </span>
//           </Fragment>
//         }
//         member2Job={
//           <Fragment>
//             <span className="about-text29">Vice President of Events</span>
//           </Fragment>
//         }
//         member1={
//           <Fragment>
//             <span className="about-text30">John Doe</span>
//           </Fragment>
//         }
//         heading1={
//           <Fragment>
//             <span className="about-text31">Meet Our Team</span>
//           </Fragment>
//         }
//         content1={
//           <Fragment>
//             <span className="about-text32">
//               Our team of dedicated student leaders works tirelessly to create a vibrant campus community through exciting events and engaging activities.
//             </span>
//           </Fragment>
//         }
//         member1Job={
//           <Fragment>
//             <span className="about-text33">President of Student Council</span>
//           </Fragment>
//         }
//         member4Job={
//           <Fragment>
//             <span className="about-text34">Treasurer</span>
//           </Fragment>
//         }
//         member3Job={
//           <Fragment>
//             <span className="about-text35">Head of Marketing</span>
//           </Fragment>
//         }
//         member3={
//           <Fragment>
//             <span className="about-text36">Alex Johnson</span>
//           </Fragment>
//         }
//         actionContent={
//           <Fragment>
//             <span className="about-text37">Get Involved in Events</span>
//           </Fragment>
//         }
//         member2={
//           <Fragment>
//             <span className="about-text38">Jane Smith</span>
//           </Fragment>
//         }
//         member3Content={
//           <Fragment>
//             <span className="about-text39">
//               Alex is a strategic thinker with a flair for promoting campus events effectively, reaching out to a wide audience and increasing student engagement.
//             </span>
//           </Fragment>
//         }
//         member1Content={
//           <Fragment>
//             <span className="about-text40">
//               John is a dedicated student leader who is passionate about enhancing campus life and organizing engaging events for fellow students.
//             </span>
//           </Fragment>
//         }
//         content2={
//           <Fragment>
//             <span className="about-text41">
//               Join us in shaping the future of campus life by participating in our upcoming events and making lasting memories with fellow students.
//             </span>
//           </Fragment>
//         }
//         member2Content={
//           <Fragment>
//             <span className="about-text42">
//               Jane is a creative event planner who brings innovative ideas to campus activities, ensuring memorable experiences for all participants.
//             </span>
//           </Fragment>
//         }
//       ></Team5>

//       {/* Features Section */}
//       <Features18
//         feature1Slogan={
//           <Fragment>
//             <span className="about-text43">Effortless Event Registration</span>
//           </Fragment>
//         }
//         feature1Title={
//           <Fragment>
//             <span className="about-text44">Easy Registration Process</span>
//           </Fragment>
//         }
//         feature1Description={
//           <Fragment>
//             <span className="about-text45">
//               Register for campus events with just a few clicks. Say goodbye to long queues and paperwork.
//             </span>
//           </Fragment>
//         }
//       ></Features18>

//       {/* Testimonials */}
//       <Testimonial2
//         author1Name={
//           <Fragment>
//             <span className="about-text46">John Smith</span>
//           </Fragment>
//         }
//         author1Position={
//           <Fragment>
//             <span className="about-text47">Senior at ABC University</span>
//           </Fragment>
//         }
//         review1={
//           <Fragment>
//             <span className="about-text48">
//               The student registration system made it so easy for me to sign up for campus events and workshops. I never miss out on any opportunities now!
//             </span>
//           </Fragment>
//         }
//       ></Testimonial2>

//       {/* Contact Section */}
//       <Contact111
//         content1={
//           <Fragment>
//             <span className="about-text49">
//               Have questions or need assistance? Feel free to reach out to us.
//             </span>
//           </Fragment>
//         }
//         email={
//           <Fragment>
//             <span className="about-text50">info@universitycampusregistration.com</span>
//           </Fragment>
//         }
//         content2={
//           <Fragment>
//             <span className="about-text51">
//               You can also visit us at our campus office during office hours.
//             </span>
//           </Fragment>
//         }
//         phone1={
//           <Fragment>
//             <span className="about-text52">+1-123-456-7890</span>
//           </Fragment>
//         }
//         heading1={
//           <Fragment>
//             <span className="about-text53">Contact Us</span>
//           </Fragment>
//         }
//         address1={
//           <Fragment>
//             <span className="about-text54">123 University Campus, City, State, Zip Code</span>
//           </Fragment>
//         }
//         content3={
//           <Fragment>
//             <span className="about-text55">
//               We are here to help you with any inquiries or support you may need.
//             </span>
//           </Fragment>
//         }
//         content5={
//           <Fragment>
//             <span className="about-text56">
//               Follow us on social media for the latest updates and announcements.
//             </span>
//           </Fragment>
//         }
//       ></Contact111>

//       {/* Footer Section */}
//       <Footer51
//         link5={
//           <Fragment>
//             <span className="about-text57">FAQs</span>
//           </Fragment>
//         }
//         action1={
//           <Fragment>
//             <span className="about-text58">Register Now</span>
//           </Fragment>
//         }
//         content1={
//           <Fragment>
//             <span className="about-text59">Stay Connected with Us</span>
//           </Fragment>
//         }
//         link1={
//           <Fragment>
//             <span className="about-text60">Events</span>
//           </Fragment>
//         }
//         privacyLink={
//           <Fragment>
//             <span className="about-text61">Privacy Policy</span>
//           </Fragment>
//         }
//         link4={
//           <