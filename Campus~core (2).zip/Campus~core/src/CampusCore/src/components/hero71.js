import React, { Fragment } from 'react'

import PropTypes from 'prop-types'

import './hero71.css'

const Hero71 = (props) => {
  return (
    <div className="thq-section-padding">
      <div className="hero71-max-width thq-section-max-width">
        <div className="hero71-content">
          <h1 className="hero71-text1 thq-heading-1">
            {props.heading1 ?? (
              <Fragment>
                <span className="hero71-text5">
                  Welcome to our Student Registration System!
                </span>
              </Fragment>
            )}
          </h1>
          <p className="hero71-text2 thq-body-large">
            {props.content1 ?? (
              <Fragment>
                <span className="hero71-text8">
                  Easily register for campus events, special lectures,
                  workshops, and social gatherings with just a few clicks!
                </span>
              </Fragment>
            )}
          </p>
          <div className="hero71-actions">
            <div className="hero71-container1">
              <button className="thq-button-filled hero71-button1">
                <span className="hero71-text3 thq-body-small">
                  {props.action1 ?? (
                    <Fragment>
                      <span className="hero71-text6">Register Now</span>
                    </Fragment>
                  )}
                </span>
              </button>
            </div>
            <div className="hero71-container2">
              <button className="thq-button-outline hero71-button2">
                <span className="hero71-text4 thq-body-small">
                  {props.action2 ?? (
                    <Fragment>
                      <span className="hero71-text7">Learn More</span>
                    </Fragment>
                  )}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

Hero71.defaultProps = {
  heading1: undefined,
  action1: undefined,
  action2: undefined,
  content1: undefined,
}

Hero71.propTypes = {
  heading1: PropTypes.element,
  action1: PropTypes.element,
  action2: PropTypes.element,
  content1: PropTypes.element,
}

export default Hero71
