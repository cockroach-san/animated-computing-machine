import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./profile.css";

// AutoSlider component: displays event info in a clickable box.
const AutoSlider = ({ events, interval = 3000, onEventClick }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (events.length === 0) return;
    const sliderInterval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % events.length);
    }, interval);
    return () => clearInterval(sliderInterval);
  }, [events, interval]);

  if (events.length === 0)
    return <p className="slider-placeholder">No events to display</p>;

  const currentEvent = events[currentIndex];

  return (
    <div
      className="auto-slider"
      onClick={() => onEventClick(currentEvent)}
      title="Click to view event details"
    >
      <img
        src={currentEvent.image}
        alt={currentEvent.title}
        className="event-image"
      />
      <div className="event-info">
        <h4>{currentEvent.title}</h4>
        <p>Date: {currentEvent.date}</p>
      </div>
    </div>
  );
};

const Profile = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("overview");

  // Profile picture state with default placeholder.
  const [profilePic, setProfilePic] = useState(
    "https://i.imgur.com/GO9phqJ.jpeg"
  );
  const [showPicOptions, setShowPicOptions] = useState(false);
  const predefinedPics = [
    "https://i.imgur.com/6VVl2Ok.jpeg",
    "https://i.imgur.com/iRVuph9.jpeg",
    "https://i.imgur.com/ctdMjLL.jpeg",
    "/Logo192.png"
  ];

  // Extended account details.
  const [editDetails, setEditDetails] = useState({
    name: "Sam",
    email: "",
    age: "",
    sex: "",
    location: "",
    phone: "",
  });

  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [registeredEvents, setRegisteredEvents] = useState([]);

  // Simulated events including a past event.
  useEffect(() => {
    const events = [
      {
        id: 1,
        title: "Tech Conference 2025",
        date: "2025/06/15",
        image: "https://images.unsplash.com/photo-1516534775068-ba3e7458af70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0Mnw&ixlib=rb-4.0.3&q=80&w=1080",
      },
      {
        id: 2,
        title: "Gaming Championship",
        date: "2025/07/20",
        image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0N3w&ixlib=rb-4.0.3&q=80&w=1080",
      },
      {
        id: 3,
        title: "Developer Meetup",
        date: "2025/08/10",
        image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0N3w&ixlib=rb-4.0.3&q=80&w=1080",
      },
      {
        id: 4,
        title: "Past Developer Meetup",
        date: "2024/12/01",
        image: "https://images.unsplash.com/photo-1583954964358-1bd7215b6f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NTgyNDI4Nnw&ixlib=rb-4.0.3&q=80&w=1080",
      },
    ];
    const currentDate = new Date();
    const upcoming = events.filter(
      (event) => new Date(event.date) >= currentDate
    );
    setUpcomingEvents(upcoming);
    setRegisteredEvents(events);
  }, []);

  const logout = () => {
    sessionStorage.removeItem("token");
    navigate("/login");
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditDetails((prevDetails) => ({ ...prevDetails, [name]: value }));
  };

  const handleSaveDetails = () => {
    alert("Your details have been updated!");
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePic(reader.result);
        setShowPicOptions(false);
      };
      reader.readAsDataURL(file);
    }
  };

  // Navigate to event details page.
  const handleEventClick = (event) => {
    navigate(`/event`);
  };

  // Filter registered events into upcoming and past.
  const currentDate = new Date();
  const upcomingRegistered = registeredEvents.filter(
    (event) => new Date(event.date) >= currentDate
  );
  const pastRegistered = registeredEvents.filter(
    (event) => new Date(event.date) < currentDate
  );

  return (
    <div className="profile-container">
      {/* Sidebar Navigation remains unchanged */}
      <aside className="profile-sidebar">
        <h2>Welcome, {editDetails.name}!</h2>
        <nav>
          <button onClick={() => setActiveSection("overview")}>
            Overview
          </button>
          <button onClick={() => setActiveSection("accountSettings")}>
            Account Settings
          </button>
          <button onClick={() => setActiveSection("events")}>Events</button>
          <button onClick={logout} className="logout-btn">
            Logout
          </button>
        </nav>
      </aside>

      {/* Main Content Area */}
      <div className="profile-content">
        {/* Overview Section */}
        {activeSection === "overview" && (
          <section className="overview-section">
            <div className="box-container">
              <h3>Overview</h3>
              <p> {editDetails.memberSince}</p>
              <div className="overview-top">
                {/* Clickable Profile Picture */}
                <div className="profile-pic-container">
                  <img
                    src={profilePic}
                    alt="Profile"
                    className="profile-pic"
                    onClick={() => setShowPicOptions(!showPicOptions)}
                    title="Click to change profile picture"
                  />
                  {showPicOptions && (
                    <div className="pic-options">
                      <div className="predefined-pics">
                        {predefinedPics.map((pic, index) => (
                          <img
                            key={index}
                            src={pic}
                            alt={`/Logo192.png ${index}`}
                            className="predefined-pic"
                            onClick={() => {
                              setProfilePic(pic);
                              setShowPicOptions(false);
                            }}
                          />
                        ))}
                      </div>
                      {/* <div className="upload-pic">
                        <label htmlFor="upload">Upload Your Own:</label>
                        <input
                          id="upload"
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                        />
                      </div> */}
                    </div>
                  )}
                </div>

                {/* Account Information Summary */}
                <div className="account-summary">
                  <h4>Account Information</h4>
                  <p>
                    <strong>Name:</strong> {editDetails.name}
                  </p>
                  {/* <p>
                    <strong>Email:</strong> {editDetails.email}
                  </p> */}
                  <p>
                    <strong>Age:</strong> {editDetails.age}
                  </p>
                  <p>
                    <strong>Sex:</strong> {editDetails.sex}
                  </p>
                  <p>
                    <strong>Location:</strong> {editDetails.location}
                  </p>
                  <p>
                    <strong>Phone:</strong> {editDetails.phone}
                  </p>
                 
                  <button onClick={() => setActiveSection("accountSettings")}>
                    Edit Details
                  </button>
                </div>
              </div>

              {/* Upcoming Campaigns & Events */}
              <div className="campaigns-section">
                <h4>Upcoming Campaigns &amp; Events</h4>
                <AutoSlider
                  events={upcomingEvents}
                  interval={3000}
                  onEventClick={handleEventClick}
                />
              </div>
            </div>
          </section>
        )}

        {/* Account Settings Section */}
        {activeSection === "accountSettings" && (
          <section className="account-settings-section">
            <div className="box-container">
              <h3>Account Settings</h3>
              <div className="edit-form">
                <div className="form-group">
                  <label htmlFor="name">Name:</label>
                  <input
                    id="name"
                    type="text"
                    name="name"
                    value={editDetails.name}
                    onChange={handleInputChange}
                  />
                </div>
                {/* <div className="form-group">
                  <label htmlFor="email">Email:</label>
                  <input
                    id="email"
                    type="email"
                    name="email"
                    value={editDetails.email}
                    onChange={handleInputChange}
                  />
                </div> */}
                <div className="form-group">
                  <label htmlFor="age">Age:</label>
                  <input
                    id="age"
                    type="number"
                    name="age"
                    value={editDetails.age}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="sex">Sex:</label>
                  <input
                    id="sex"
                    type="text"
                    name="sex"
                    value={editDetails.sex}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="location">Location:</label>
                  <input
                    id="location"
                    type="text"
                    name="location"
                    value={editDetails.location}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="phone">Phone:</label>
                  <input
                    id="phone"
                    type="text"
                    name="phone"
                    value={editDetails.phone}
                    onChange={handleInputChange}
                  />
                </div>
              
                <button onClick={handleSaveDetails}>Save Changes</button>
              </div>
            </div>
          </section>
        )}

        {/* Events Section: Upcoming and Past */}
        {activeSection === "events" && (
          <section className="events-section">
            <div className="box-container">
              <h3>Registered Events</h3>

              <div className="registered-events-group">
                <h4>Upcoming Events</h4>
                <div className="registered-events">
                  {upcomingRegistered.length > 0 ? (
                    upcomingRegistered.map((event, index) => (
                      <div
                        className="registered-event-card"
                        key={index}
                        onClick={() => handleEventClick(event)}
                        title="Click to view event details"
                      >
                        <img
                          src={event.image}
                          alt={event.title}
                          className="event-card-img"
                        />
                        <h4>{event.title}</h4>
                        <p>Date: {event.date}</p>
                      </div>
                    ))
                  ) : (
                    <p>No upcoming events.</p>
                  )}
                </div>
              </div>

              <div className="registered-events-group">
                <h4>Event History</h4>
                <div className="registered-events">
                  {pastRegistered.length > 0 ? (
                    pastRegistered.map((event, index) => (
                      <div className="registered-event-card" key={index}>
                        <img
                          src={event.image}
                          alt={event.title}
                          className="event-card-img"
                        />
                        <h4>{event.title}</h4>
                        <p>Date: {event.date}</p>
                      </div>
                    ))
                  ) : (
                    <p>No past events.</p>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default Profile;
