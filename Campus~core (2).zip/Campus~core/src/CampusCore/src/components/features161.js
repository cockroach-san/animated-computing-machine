import React, { Fragment } from 'react'

import PropTypes from 'prop-types'

import './features161.css'

const Features161 = (props) => {
  return (
    <div className="features161-layout300 thq-section-padding">
      <div className="features161-max-width thq-section-max-width">
        <div className="features161-section-title">
          {/* <span className="features161-text10 thq-body-small">
            {props.slogan1 ?? (
              <Fragment>
                <span className="features161-text21">
                  Simplify your campus event experience with our registration
                  system.
                </span>
              </Fragment>
            )}
          </span> */}
          <div className="features161-content1">
            <h2 className="features161-text11 thq-heading-2">
              {props.heading1 ?? (
                <Fragment>
                  <span className="features161-text15">Key Features</span>
                </Fragment>
              )}
            </h2>
            <span className="features161-text12 thq-body-large">
              {props.content1 ?? (
                <Fragment>
                  <span className="features161-text16">
                    Explore upcoming events, lectures, and workshops on Campus~Core.
                  </span>
                </Fragment>
              )}
            </span>
          </div>
        </div>
        <div className="features161-content2">
          <div className="features161-row thq-flex-row">
            <div className="features161-feature1">
              <img
                alt={props.feature1ImageAlt}
                src={props.feature1ImageSrc}
                className="thq-img-ratio-4-3"
              />
              <div className="features161-content3">
                <h3 className="features161-feature1-title thq-heading-3">
                  {props.feature1Title ?? (
                    <Fragment>
                      <span className="features161-text19">
                        Event Registration
                      </span>
                    </Fragment>
                  )}
                </h3>
                <span className="thq-body-small">
                  {props.feature1Description ?? (
                    <Fragment>
                      <span className="features161-text14">
                        Easily register for campus events with just a few
                        clicks.
                      </span>
                    </Fragment>
                  )}
                </span>
              </div>
            </div>
            <div className="features161-feature2">
              <img
                alt={props.feature2ImageAlt}
                src={props.feature2ImageSrc}
                className="thq-img-ratio-4-3"
              />
              <div className="features161-content4">
                <h3 className="thq-heading-3">
                  {props.feature2Title ?? (
                    <Fragment>
                      <span className="features161-text17">
                        Manage Registrations
                      </span>
                    </Fragment>
                  )}
                </h3>
                <span className="thq-body-small">
                  {props.feature2Description ?? (
                    <Fragment>
                      <span className="features161-text18">
                        Effortlessly manage your event registrations in one
                        place.
                      </span>
                    </Fragment>
                  )}
                </span>
              </div>
            </div>
            <div className="features161-feature3">
              <img
                alt={props.feature3ImageAlt}
                src={props.feature3ImageSrc}
                className="thq-img-ratio-4-3"
              />
              <div className="features161-content5">
                <h3 className="thq-heading-3">
                  {props.feature3Title ?? (
                    <Fragment>
                      <span className="features161-text13">Stay Updated</span>
                    </Fragment>
                  )}
                </h3>
                <span className="thq-body-small">
                  {props.feature3Description ?? (
                    <Fragment>
                      <span className="features161-text20">
                        Receive timely updates on all activities happening on
                        campus.
                      </span>
                    </Fragment>
                  )}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

Features161.defaultProps = {
  feature3Title: undefined,
  feature1Description: undefined,
  feature2ImageAlt: 'Manage Registrations Image',
  feature1ImageSrc:
    'https://images.unsplash.com/photo-1696613496496-1c7b2a55e7d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NTgyNDI4Nnw&ixlib=rb-4.0.3&q=80&w=1080',
  heading1: undefined,
  content1: undefined,
  feature3ImageAlt: 'Stay Updated Image',
  feature3ImageSrc:
    'https://images.unsplash.com/photo-1583954964358-1bd7215b6f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NTgyNDI4Nnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature2Title: undefined,
  feature2Description: undefined,
  feature1Title: undefined,
  feature1ImageAlt: 'Event Registration Image',
  feature3Description: undefined,
  feature2ImageSrc:
    'https://images.unsplash.com/photo-1618255630366-f402c45736f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NTgyNDI4N3w&ixlib=rb-4.0.3&q=80&w=1080',
  slogan1: undefined,
}

Features161.propTypes = {
  feature3Title: PropTypes.element,
  feature1Description: PropTypes.element,
  feature2ImageAlt: PropTypes.string,
  feature1ImageSrc: PropTypes.string,
  heading1: PropTypes.element,
  content1: PropTypes.element,
  feature3ImageAlt: PropTypes.string,
  feature3ImageSrc: PropTypes.string,
  feature2Title: PropTypes.element,
  feature2Description: PropTypes.element,
  feature1Title: PropTypes.element,
  feature1ImageAlt: PropTypes.string,
  feature3Description: PropTypes.element,
  feature2ImageSrc: PropTypes.string,
  slogan1: PropTypes.element,
}

export default Features161
