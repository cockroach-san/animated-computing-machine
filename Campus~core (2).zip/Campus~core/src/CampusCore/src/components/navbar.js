import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import PropTypes from "prop-types"; // ✅ Ensure PropTypes is imported
import "./navbar.css";

const Navbar = (props) => {
    const navigate = useNavigate();
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const token = sessionStorage.getItem("token"); // ✅ Check if user is logged in
    const profilePic = sessionStorage.getItem("profilePic") || "https://i.imgur.com/GO9phqJ.jpeg"; // ✅ Store user profile picture

    const logout = () => {
        sessionStorage.removeItem("token"); // ✅ Clear JWT token
        sessionStorage.removeItem("profilePic"); // ✅ Remove stored profile picture
        setDropdownOpen(false); // ✅ Close dropdown on logout
        navigate("/login"); // ✅ Redirect to login after logout
    };

    // ✅ Handles dropdown toggling via click
    const handleDropdownToggle = () => {
        setDropdownOpen((prevState) => !prevState);
    };

    // ✅ Close dropdown when clicking outside
    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (!event.target.closest(".profile-menu")) {
                setDropdownOpen(false);
            }
        };

        document.addEventListener("click", handleOutsideClick);
        return () => document.removeEventListener("click", handleOutsideClick);
    }, []);

    return (
        <header className="navbar-container">
            <header className="navbar-navbar-interactive">
                <Link to="/" className="navbar-link">
                    <img 
                        alt={props.logoAlt} 
                        src={props.logoSrc} 
                        className="navbar-image1" 
                        onError={(e) => { e.target.src = "https://i.imgur.com/ksjjhUR.png"; }} 
                    />
                </Link>

                <div className="navbar-desktop-menu">
                    {/* Navigation Links */}
                    <nav className="navbar-links1">
                        <Link to="/" className="thq-link thq-body-small">{props.link1}</Link>
                        <Link to="/event" className="thq-link thq-body-small">{props.link2}</Link>
                        <Link to="/registration" className="thq-link thq-body-small">{props.link5}</Link>
                        <Link to="/about" className="thq-link thq-body-small">{props.link3}</Link>
                    </nav>

                    {/* ✅ Show Profile or Login/Register */}
                    {token ? (
                        <div className="profile-menu">
                            <img 
                                src={profilePic} 
                                alt="Profile" 
                                className="profile-icon" 
                                onClick={handleDropdownToggle} // ✅ Click toggles dropdown
                            />
                            
                            {dropdownOpen && (
                                <div className="dropdown-menu">
                                    <Link to="/profile" className="dropdown-item">Account</Link>
                                    {/* <Link to="/profile" className="dropdown-item">My Events</Link>
                                    <Link to="/profile" className="dropdown-item">Event History</Link> */}
                                    <button onClick={logout} className="dropdown-item logout-btn">Logout</button>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="navbar-buttons1">
                            <Link to="/login" className="navbar-action11 thq-button-animated thq-button-filled">Login</Link>
                            <Link to="/register" className="navbar-action21 thq-button-animated thq-button-outline" >Register</Link>
                        </div>
                    )}
                </div>
            </header>
        </header>
    );
};

// Default props for the Navbar
Navbar.defaultProps = {
    logoSrc: "/logoo.png",
    link5: "Registration",
    link1: "Home",
    link2: "Events",
    link3: "About us",
    logoAlt: "Logo",
};

// Prop types validation
Navbar.propTypes = {
    logoSrc: PropTypes.string,
    link5: PropTypes.string,
    link1: PropTypes.string,
    link2: PropTypes.string,
    link3: PropTypes.string,
    logoAlt: PropTypes.string,
};

export default Navbar;