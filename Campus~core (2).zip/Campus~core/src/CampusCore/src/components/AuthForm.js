import React, { useState, useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "./AuthForm.css";

const AuthForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [signUpError, setSignUpError] = useState("");
  const [signUpSuccess, setSignUpSuccess] = useState("");
  const [signInError, setSignInError] = useState("");

  // Automatically toggle between Sign-Up and Sign-In based on the URL
  useEffect(() => {
    if (location.pathname === "/register") {
      setIsSignUp(true);
    } else {
      setIsSignUp(false);
    }
  }, [location.pathname]);

  // Backend integration for Sign-Up
  const handleSignUp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSignUpError("");
    setSignUpSuccess("");

    // Using element indexes:
    // Index 0: Name, Index 1: Email, Index 2: Password.
    const data = {
      username: e.target[0].value.trim(),
      email: e.target[1].value.trim(),
      password: e.target[2].value,
    };

    // Basic validation check
    if (!data.username || !data.email || !data.password) {
      setSignUpError("All fields are required.");
      setLoading(false);
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/register",
        data,
        { headers: { "Content-Type": "application/json" } }
      );
      if (response.status === 200 || response.status === 201) {
        setSignUpSuccess(
          response.data.message || "Account created successfully!"
        );
        // Redirect to login page after registration (delay 2 seconds)
        setTimeout(() => {
          navigate("/login");
        }, 2000);
      }
    } catch (error) {
      setSignUpError(
        error.response?.data?.error || "Registration failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  // Backend integration for Sign-In
  const handleSignIn = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSignInError("");

    // Using element indexes:
    // Index 0: Email, Index 1: Password.
    const data = {
      email: e.target[0].value.trim(),
      password: e.target[1].value,
    };

    if (!data.email || !data.password) {
      setSignInError("Email and password are required.");
      setLoading(false);
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/login",
        data,
        { headers: { "Content-Type": "application/json" } }
      );
      if (response.status === 200 && response.data.token) {
        // Store token and user role in sessionStorage
        sessionStorage.setItem("token", response.data.token);
        sessionStorage.setItem("role", response.data.role);
        console.log("Sign In:", response.data.message);
        // Redirect the user to the profile/dashboard page
        navigate("/");
      } else {
        setSignInError(response.data.message || "Invalid credentials.");
      }
    } catch (error) {
      setSignInError(
        error.response?.data?.error || "Login failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  // Update the active mode and URL when quick links are clicked
  const switchToSignIn = () => {
    navigate("/login");
    setIsSignUp(false);
  };

  const switchToSignUp = () => {
    navigate("/register");
    setIsSignUp(true);
  };

  return (
    <div className="login-page-container">
      <div className={`container ${isSignUp ? "right-panel-active" : ""}`}>
        {/* Sign-Up Form */}
        <div className="form-container sign-up-container">
          <form onSubmit={handleSignUp}>
            <h1>Create Account</h1>
            <div className="social-container">
              <a href="http://localhost:5000/api/auth/facebook" className="social">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="http://localhost:5000/api/auth/google" className="social">
                <i className="fab fa-google-plus-g"></i>
              </a>
              <a href="http://localhost:5000/api/auth/linkedin" className="social">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
            <span>Use your email for registration</span>
            <input type="text" placeholder="Name" />
            <input type="email" placeholder="Email" />
            <input type="password" placeholder="Password" />
            {signUpError && <p className="error-message">{signUpError}</p>}
            {signUpSuccess && <p className="success-message">{signUpSuccess}</p>}
            <button type="submit" disabled={loading}>
              {loading ? "Processing..." : "Sign Up"}
            </button>
          </form>
        </div>

        {/* Sign-In Form */}
        <div className="form-container sign-in-container">
          <form onSubmit={handleSignIn}>
            <h1>Sign in</h1>
            <div className="social-container">
              <a href="http://localhost:5000/api/auth/facebook" className="social">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="http://localhost:5000/api/auth/google" className="social">
                <i className="fab fa-google-plus-g"></i>
              </a>
              <a href="http://localhost:5000/api/auth/linkedin" className="social">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
            <input type="email" placeholder="Email" />
            <input type="password" placeholder="Password" />
            <Link to="/forgotpassword" className="forgot-password">
              Forgot Password?
            </Link>
            {signInError && <p className="error-message">{signInError}</p>}
            <button type="submit" disabled={loading}>
              {loading ? "Processing..." : "Sign In"}
            </button>
          </form>
        </div>

        {/* Overlay Section with Quick Links */}
        <div className="overlay-container">
          <div className="overlay">
            <div className="overlay-panel overlay-left">
              <h1>Welcome Back!</h1>
              <p>Sign in to access your account</p>
              <button className="ghost" onClick={switchToSignIn}>
                Sign In
              </button>
            </div>
            <div className="overlay-panel overlay-right">
              <h1>Hello, Friend!</h1>
              <p>Enter your details and start your journey</p>
              <button className="ghost" onClick={switchToSignUp}>
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;