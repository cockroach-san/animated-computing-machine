import React, { useState, Fragment } from 'react';
import PropTypes from 'prop-types';
import './pricing141.css';

// Helper function: if value is a React element, extract its text content; otherwise, return string or default.
const getTextValue = (value, defaultValue) => {
  if (typeof value === 'string') {
    return value;
  } else if (React.isValidElement(value) && value.props && value.props.children) {
    // If children is an array, join them into a string.
    if (Array.isArray(value.props.children)) {
      return value.props.children.join('');
    }
    return value.props.children;
  }
  return defaultValue;
};

const Pricing141 = (props) => {
  const [isMonthly, setIsMonthly] = useState(true); // Default state: Events tab is active

  // New function to build query and redirect to /register with event details
  const handleRegisterClick = (title, description, venue, date, time) => {
    const queryString = new URLSearchParams({
      title,
      description,
      venue,
      date,
      time
    }).toString();
    window.location.href = `/registration?${queryString}`;
  };

  return (
    <div className={`pricing141-pricing23 thq-section-padding ${props.rootClassName}`}>
      <div className="pricing141-max-width thq-section-max-width">
        <div className="pricing141-section-title">
          <div className="pricing141-content">
            <h2 className="pricing141-text10 thq-heading-2">
              {props.heading1 ?? (
                <Fragment>
                  <span className="pricing141-text78">Events</span>
                </Fragment>
              )}
            </h2>
            <p className="pricing141-text11 thq-body-large">
              {props.content2 ?? (
                <Fragment>
                  <span className="pricing141-text77">Join Our Events</span>
                </Fragment>
              )}
            </p>
          </div>
        </div>

        {/* Buttons for toggling */}
        <div className="pricing141-tabs">
          <button
            onClick={() => setIsMonthly(true)} // Show Events
            className="pricing141-button1 thq-button-animated thq-button-filled"
          >
            <span className="thq-body-small">Events</span>
          </button>
          <button
            onClick={() => setIsMonthly(false)} // Show Special Lectures
            className="pricing141-button4 thq-button-outline thq-button-animated"
          >
            <span className="thq-body-small">Special Lectures</span>
          </button>
        </div>

        {/* Conditional Rendering for Events and Special Lectures */}
        <div className="pricing141-container">
          {isMonthly ? (
            <>
              {/* Part 1: Tech Square */}
              <div className="features4-feature11">
                <img
                  alt={props.feature1ImageAlt}
                  src={props.feature1ImageSrc}
                  className="thq-img-ratio-4-3"
                />
                <div className="features4-content1 thq-flex-column">
                  <h3 className="features4-title11 thq-heading-3">
                    {props.feature1Title ?? (
                      <Fragment>
                        <span className="features4-text18">Tech Square</span>
                      </Fragment>
                    )}
                  </h3>
                  <span className="features4-description11 thq-body-small">
                    {props.feature1Description ?? (
                      <Fragment>
                        <span className="features4-text24">
                          Talk with product experts and experience innovations in Tech Square.
                        </span>
                      </Fragment>
                    )}
                  </span>
                  {/* Venue, Date, Time */}
                  <p className="event-details">📍 Venue: {props.feature1Venue}</p>
                  <p className="event-details">📅 Date: {props.feature1Date}</p>
                  <p className="event-details">⏰ Time: {props.feature1Time}</p>

                  <button
                    onClick={() =>
                      handleRegisterClick(
                        getTextValue(props.feature1Title, "Tech Square"),
                        getTextValue(
                          props.feature1Description,
                          "Talk with product experts and experience innovations in Tech Square."
                        ),
                        props.feature1Venue,
                        props.feature1Date,
                        props.feature1Time
                      )
                    }
                    className="features4-button1 thq-button-animated thq-button-filled"
                  >
                    <span className="thq-body-small">Explore Tech Square</span>
                  </button>
                </div>
              </div>

              {/* Part 2: Coding Olympics */}
              <div className="features4-feature21">
                <img
                  alt={props.feature2ImageAlt}
                  src={props.feature2ImageSrc}
                  className="thq-img-ratio-4-3"
                />
                <div className="features4-content2 thq-flex-column">
                  <h3 className="features4-title21 thq-heading-3">
                    {props.feature2Title ?? (
                      <Fragment>
                        <span className="features4-text21">Coding Olympics</span>
                      </Fragment>
                    )}
                  </h3>
                  <span className="features4-description21 thq-body-small">
                    {props.feature2Description ?? (
                      <Fragment>
                        <span className="features4-text20">
                          Exciting coding contests designed to challenge your speed, precision, and programming expertise.
                        </span>
                      </Fragment>
                    )}
                  </span>
                  {/* Venue, Date, Time */}
                  <p className="event-details">📍 Venue: {props.feature2Venue}</p>
                  <p className="event-details">📅 Date: {props.feature2Date}</p>
                  <p className="event-details">⏰ Time: {props.feature2Time}</p>

                  <button
                    onClick={() =>
                      handleRegisterClick(
                        getTextValue(props.feature2Title, "Coding Olympics"),
                        getTextValue(
                          props.feature2Description,
                          "Exciting coding contests designed to challenge your speed, precision, and programming expertise."
                        ),
                        props.feature2Venue,
                        props.feature2Date,
                        props.feature2Time
                      )
                    }
                    className="features4-button2 thq-button-animated thq-button-filled"
                  >
                    <span className="thq-body-small">Register Now</span>
                  </button>
                </div>
              </div>

              {/* Part 3: Blockchain & Workshops */}
              <div className="features4-feature3">
                <img
                  alt={props.feature3ImageAlt}
                  src={props.feature3ImageSrc}
                  className="thq-img-ratio-4-3"
                />
                <div className="features4-content3 thq-flex-column">
                  <h3 className="features4-title3 thq-heading-3">
                    {props.feature3Title ?? (
                      <Fragment>
                        <span className="features4-text17">Blockchain & Workshops</span>
                      </Fragment>
                    )}
                  </h3>
                  <span className="features4-description3 thq-body-small">
                    {props.feature3Description ?? (
                      <Fragment>
                        <span className="features4-text25">
                          Explore blockchain beyond cryptocurrency and engage in interactive workshops to enhance your tech skills.
                        </span>
                      </Fragment>
                    )}
                  </span>
                  {/* Venue, Date, Time */}
                  <p className="event-details">📍 Venue: {props.feature3Venue}</p>
                  <p className="event-details">📅 Date: {props.feature3Date}</p>
                  <p className="event-details">⏰ Time: {props.feature3Time}</p>

                  <button
                    onClick={() =>
                      handleRegisterClick(
                        getTextValue(props.feature3Title, "Blockchain & Workshops"),
                        getTextValue(
                          props.feature3Description,
                          "Explore blockchain beyond cryptocurrency and engage in interactive workshops to enhance your tech skills."
                        ),
                        props.feature3Venue,
                        props.feature3Date,
                        props.feature3Time
                      )
                    }
                    className="features4-button3 thq-button-animated thq-button-filled"
                  >
                    <span className="thq-body-small">Join Workshops</span>
                  </button>
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Special Lectures Columns */}
              <div className="features4-feature5">
                <img
                  alt="Lectures"
                  src={props.feature5ImageSrc}
                  className="thq-img-ratio-4-3"
                />
                <div className="features4-content3 thq-flex-column">
                  <h3 className="features4-title3 thq-heading-3">
                    {props.feature3Title ?? (
                      <Fragment>
                        <span className="features4-text17">AI and Machine Learning</span>
                      </Fragment>
                    )}
                  </h3>
                  <span className="features4-description3 thq-body-small">
                    {props.feature3Description ?? (
                      <Fragment>
                        <span className="features4-text25">
                          Learn from top experts in a series of exclusive lectures.
                        </span>
                      </Fragment>
                    )}
                  </span>
                  {/* Venue, Date, Time */}
                  <p className="event-details">📍 Venue: {props.feature4Venue}</p>
                  <p className="event-details">📅 Date: {props.feature4Date}</p>
                  <p className="event-details">⏰ Time: {props.feature4Time}</p>

                  <button
                    onClick={() =>
                      handleRegisterClick(
                        getTextValue(props.feature4Title, "AI and Machine Learning"),
                        getTextValue(
                          props.feature4Description,
                          "Learn from top experts in a series of exclusive lectures."
                        ),
                        props.feature4Venue,
                        props.feature4Date,
                        props.feature4Time
                      )
                    }
                    className="features4-button3 thq-button-animated thq-button-filled"
                  >
                    <span className="thq-body-small">Join Lecture</span>
                  </button>
                </div>
              </div>

              <div className="features4-feature4">
                <img
                  alt="Event Speakers"
                  src={props.feature4ImageSrc}
                  className="thq-img-ratio-4-3"
                />
                <div className="features4-content4 thq-flex-column">
                  <h3 className="features4-title4 thq-heading-3">
                    {props.feature4Title ?? (
                      <Fragment>
                        <span className="features4-text22">Navigating the Metaverse</span>
                      </Fragment>
                    )}
                  </h3>
                  <span className="features4-description4 thq-body-small">
                    {props.feature4Description ?? (
                      <Fragment>
                        <span className="features4-text23">
                          Meet renowned speakers sharing groundbreaking insights.
                        </span>
                      </Fragment>
                    )}
                  </span>
                  {/* Venue, Date, Time */}
                  <p className="event-details">📍 Venue: {props.feature5Venue}</p>
                  <p className="event-details">📅 Date: {props.feature5Date}</p>
                  <p className="event-details">⏰ Time: {props.feature5Time}</p>

                  <button
                    onClick={() =>
                      handleRegisterClick(
                        getTextValue(props.feature4Title, "Navigating the Metaverse"),
                        getTextValue(
                          props.feature4Description,
                          "Meet renowned speakers sharing groundbreaking insights."
                        ),
                        props.feature5Venue,
                        props.feature5Date,
                        props.feature5Time
                      )
                    }
                    className="features4-button4 thq-button-animated thq-button-filled"
                  >
                    <span className="thq-body-small">Join Lecture</span>
                  </button>
                </div>
              </div>

              {/* Section 3: Special Lecture */}
              <div className="features4-feature4">
                <img
                  alt="Event Speakers"
                  src={props.feature7ImageSrc}
                  className="thq-img-ratio-4-3"
                />
                <div className="features4-content4 thq-flex-column">
                  <h3 className="features4-title4 thq-heading-3">
                    {props.feature4Title ?? (
                      <Fragment>
                        <span className="features4-text22">Blockchain Beyond Bitcoin</span>
                      </Fragment>
                    )}
                  </h3>
                  <span className="features4-description4 thq-body-small">
                    {props.feature4Description ?? (
                      <Fragment>
                        <span className="features4-text23">
                          Blockchain technology in industries beyond cryptocurrency.
                        </span>
                      </Fragment>
                    )}
                  </span>
                  {/* Venue, Date, Time */}
                  <p className="event-details">📍 Venue: {props.feature7Venue}</p>
                  <p className="event-details">📅 Date: {props.feature7Date}</p>
                  <p className="event-details">⏰ Time: {props.feature7Time}</p>

                  <button
                    onClick={() =>
                      handleRegisterClick(
                        getTextValue(props.feature4Title, "Blockchain Beyond Bitcoin"),
                        getTextValue(
                          props.feature4Description,
                          "Blockchain technology in industries beyond cryptocurrency."
                        ),
                        props.feature7Venue,
                        props.feature7Date,
                        props.feature7Time
                      )
                    }
                    className="features4-button4 thq-button-animated thq-button-filled"
                  >
                    <span className="thq-body-small">Join Lecture</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

Pricing141.defaultProps = {
  rootClassName: '',
  content2: undefined,
  heading1: undefined,
  feature1Title: undefined,
  feature1Description: undefined,
  feature2ImageAlt: '',
  feature1ImageSrc:
    'https://images.unsplash.com/photo-1597026405082-eda9beae7513?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NTgyNDg0Mnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature2ImageSrc:
    'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0N3w&ixlib=rb-4.0.3&q=80&w=1080',
  feature3ImageAlt: '',
  feature4ImageSrc:
    'https://images.unsplash.com/photo-1557804506-669a67965ba0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0N3w&ixlib=rb-4.0.3&q=80&w=1080',
  feature4ImageAlt: '',
  feature7ImageSrc:
    'https://images.unsplash.com/photo-1620778184222-6aee903c672e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0Nnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature5ImageSrc:
    'https://images.unsplash.com/photo-1525540810550-5032f5d191b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0Nnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature3ImageSrc:
    'https://images.unsplash.com/photo-1507208773393-40d9fc670acf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0NDgxNzM0Nnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature3Title: undefined,
  feature3Description: undefined,
  feature4Description: undefined,
  /* Added Venue, Date, Time in Default Props */
  feature1Venue: 'Innovation Hall',
  feature1Date: 'May 10, 2025',
  feature1Time: '2:00 PM - 5:00 PM',

  feature2Venue: 'Auditorium A',
  feature2Date: 'May 12, 2025',
  feature2Time: '10:00 AM - 4:00 PM',

  feature3Venue: 'Tech Lab 3',
  feature3Date: 'May 14, 2025',
  feature3Time: '3:00 PM - 6:00 PM',

  feature4Venue: 'Turing Block',
  feature4Date: 'May 20, 2025',
  feature4Time: '12:00 PM - 3:00 PM',

  feature5Venue: 'Auditorium B',
  feature5Date: 'July 12, 2025',
  feature5Time: '10:00 AM - 4:00 PM',

  feature7Venue: 'Newton Block',
  feature7Date: 'June 14, 2025',
  feature7Time: '3:00 PM - 6:00 PM',
};

Pricing141.propTypes = {
  rootClassName: PropTypes.string,
  content2: PropTypes.element,
  heading1: PropTypes.element,
  feature1Title: PropTypes.element,
  feature1Description: PropTypes.element,
  feature2ImageAlt: PropTypes.string,
  feature2ImageSrc: PropTypes.string,
  feature7ImageSrc: PropTypes.string,
  feature1ImageSrc: PropTypes.string,
  feature3ImageAlt: PropTypes.string,
  feature3ImageSrc: PropTypes.string,
  feature5ImageSrc: PropTypes.string,
  feature4ImageAlt: PropTypes.string,
  feature4ImageSrc: PropTypes.string,
  feature3Title: PropTypes.element,
  feature3Description: PropTypes.element,
  feature4Description: PropTypes.element,
};

export default Pricing141;
