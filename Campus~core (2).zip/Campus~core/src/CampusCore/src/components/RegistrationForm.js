import React, { useState, useEffect } from "react";
import styles from "./Registration.module.css";

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    rollNo: "",
    gender: "",
    department: "",
    event: "",
    date: "",
    time: "",
    venue: "",
    preference: ""
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const eventField = params.get("title") || params.get("event") || "";
    const rawDateField = params.get("date") || "";
    const rawTimeField = params.get("time") || "";
    const venueField = params.get("venue") || "";

    let convertedDate = rawDateField;
    if (rawDateField) {
      const parsedDate = new Date(rawDateField);
      if (!isNaN(parsedDate.getTime())) {
        const year = parsedDate.getFullYear();
        const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
        const day = String(parsedDate.getDate()).padStart(2, '0');
        convertedDate = `${year}-${month}-${day}`;
      }
    }

    let convertedTime = rawTimeField;
    if (rawTimeField) {
      let timePart = rawTimeField.includes("-") ? rawTimeField.split("-")[0].trim() : rawTimeField;
      const testTime = new Date("1970-01-01 " + timePart);
      if (!isNaN(testTime.getTime())) {
        const hours = testTime.getHours().toString().padStart(2, "0");
        const minutes = testTime.getMinutes().toString().padStart(2, "0");
        convertedTime = `${hours}:${minutes}`;
      }
    }

    if (eventField || convertedDate || convertedTime || venueField) {
      setFormData((prev) => ({
        ...prev,
        event: eventField,
        date: convertedDate,
        time: convertedTime,
        venue: venueField
      }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleReset = () => {
    setFormData({
      fullName: "",
      rollNo: "",
      gender: "",
      department: "",
      event: "",
      date: "",
      time: "",
      venue: "",
      preference: ""
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token"); // Ensure user is authenticated
      if (!token) {
        alert("Unauthorized: Please log in first.");
        return;
      }

      const response = await fetch("http://localhost:5000/api/registration", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}` // Include authentication token
        },
        body: JSON.stringify(formData),
      });

      if (response.status === 401) {
        throw new Error("Unauthorized: Your session might have expired. Please log in again.");
      }

      const data = await response.json();
      if (response.ok) {
        console.log("Registration successful:", data);
        alert("Registration successful!");
      } else {
        console.error("Registration failed:", JSON.stringify(data, null, 2));
        alert("Registration failed: " + (data.error || "Please try again."));
      }
    } catch (error) {
      console.error("Error submitting registration:", error.message || JSON.stringify(error, null, 2));
      alert("Error submitting registration. Please check the API response.");
    }
    handleReset();
  };

  return (
    <div className={styles.registrationPage}>
      <div className={styles.container}>
        <header className={styles.header}>Event Registration</header>
        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.fieldGroup}>
            <h3>Student Information</h3>
            <div className={styles.inputBox}>
              <label htmlFor="fullName">Full Name</label>
              <input type="text" id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} className={styles.inputField} required />
            </div>
            <div className={styles.inputBox}>
              <label htmlFor="rollNo">Roll No</label>
              <input type="text" id="rollNo" name="rollNo" value={formData.rollNo} onChange={handleChange} className={styles.inputField} required />
            </div>
            <div className={styles.inputBox}>
              <label htmlFor="gender">Gender</label>
              <select id="gender" name="gender" value={formData.gender} onChange={handleChange} className={styles.selectField} required>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div className={styles.inputBox}>
              <label htmlFor="department">Department</label>
              <input type="text" id="department" name="department" value={formData.department} onChange={handleChange} className={styles.inputField} required />
            </div>
          </div>

          <div className={styles.fieldGroup}>
            <h3>Event & Lecture Details</h3>
            <div className={styles.inputBox}>
              <label htmlFor="event">Select Event</label>
              <input type="text" id="event" name="event" value={formData.event} onChange={handleChange} className={styles.inputField} required />
            </div>
            <div className={styles.inputBox}>
              <label htmlFor="date">Date</label>
              <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} className={styles.inputField} required />
            </div>
            <div className={styles.inputBox}>
              <label htmlFor="time">Time</label>
              <input type="time" id="time" name="time" value={formData.time} onChange={handleChange} className={styles.inputField} required />
            </div>
            <div className={styles.inputBox}>
              <label htmlFor="venue">Venue</label>
              <input type="text" id="venue" name="venue" value={formData.venue} onChange={handleChange} className={styles.inputField} required />
            </div>
          </div>

          <div className={styles.actionRow}>
            <div className={styles.preferenceWrapper}>
              <label>Preference</label>
              <div className={styles.radioGroup}>
                <label><input type="radio" name="preference" value="Virtual" checked={formData.preference === "Virtual"} onChange={handleChange} required /> Virtual</label>
                <label><input type="radio" name="preference" value="In-Person" checked={formData.preference === "In-Person"} onChange={handleChange} /> In-Person</label>
              </div>
            </div>
            <div className={styles.buttonGroup}>
              <button type="button" onClick={handleReset} className={styles.resetButton}>Reset</button>
              <button type="submit" className={styles.submitButtonSmall}>Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegistrationForm;
