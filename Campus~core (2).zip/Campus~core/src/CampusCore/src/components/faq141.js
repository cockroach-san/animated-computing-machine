import React, { useState, Fragment } from 'react'

import PropTypes from 'prop-types'

import './faq141.css'

const FAQ141 = (props) => {
  const [faq1Visible, setFaq1Visible] = useState(false)
  const [faq5Visible, setFaq5Visible] = useState(false)
  const [faq4Visible, setFaq4Visible] = useState(false)
  const [faq3Visible, setFaq3Visible] = useState(false)
  const [faq2Visible, setFaq2Visible] = useState(false)
  return (
    <div className="faq141faq8 thq-section-padding">
      <div className="faq141-max-width thq-section-max-width">
        <div className="faq141-container10 thq-flex-column">
          <div className="faq141-section-title thq-flex-column">
            <h2 className="faq141-text10 thq-heading-2">
              {props.heading1 ?? (
                <Fragment>
                  <span className="faq141-text29">FAQs</span>
                </Fragment>
              )}
            </h2>
            <p className="faq141-text11 thq-body-large">
              {props.content1 ?? (
                <Fragment>
                  <span className="faq141-text31">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Suspendisse varius enim in eros elementum tristique.
                  </span>
                </Fragment>
              )}
            </p>
            {/* <button type="button" className="thq-button-filled">
              <span>
                {props.action1 ?? (
                  <Fragment>
                    <span className="faq141-text21">Contact</span>
                  </Fragment>
                )}
              </span>
            </button> */}
          </div>
          <div className="faq141-list thq-flex-column">
            <div className="thq-divider-horizontal"></div>
            <div className="faq141-faq1">
              <div
                onClick={() => setFaq1Visible(!faq1Visible)}
                className="faq141-trigger1"
              >
                <p className="faq141-faq1-question1 thq-body-large">
                  {props.faq1Question ?? (
                    <Fragment>
                      <span className="faq141-text30">
                        How can I register for campus events?
                      </span>
                    </Fragment>
                  )}
                </p>
                <div className="faq141-icons-container1">
                  {!faq1Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon10">
                        <path d="M316 366l196 196 196-196 60 60-256 256-256-256z"></path>
                      </svg>
                    </div>
                  )}
                  {faq1Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon12">
                        <path d="M316 658l-60-60 256-256 256 256-60 60-196-196z"></path>
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              {faq1Visible && (
                <div className="faq141-container13">
                  <span className="thq-body-small">
                  Visit the Campus Events page and fill out the registration form for the event you'd like to attend.

                  </span>
                </div>
              )}
            </div>
            <div className="thq-divider-horizontal"></div>
            <div className="faq141-faq2">
              <div
                onClick={() => setFaq2Visible(!faq2Visible)}
                className="faq141-trigger2"
              >
                <p className="faq141-faq2-question1 thq-body-large">
                  {props.faq2Question ?? (
                    <Fragment>
                      <span className="faq141-text25">
                        Can I cancel my event registration?
                      </span>
                    </Fragment>
                  )}
                </p>
                <div className="faq141-icons-container2">
                  {!faq2Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon14">
                        <path d="M316 366l196 196 196-196 60 60-256 256-256-256z"></path>
                      </svg>
                    </div>
                  )}
                  {faq2Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon16">
                        <path d="M316 658l-60-60 256-256 256 256-60 60-196-196z"></path>
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              {faq2Visible && (
                <div className="faq141-container16">
                  <span className="thq-body-small">
                  Yes, you can cancel your registration by contacting the campus events team at support@campusevents.com. Include your name, the event name, and your registration details in the email. Please note that cancellation policies may vary depending on the event.

                  </span>
                </div>
              )}
            </div>
            <div className="thq-divider-horizontal"></div>
            <div className="faq141-faq3">
              <div
                onClick={() => setFaq3Visible(!faq3Visible)}
                className="faq141-trigger3"
              >
                <p className="faq141-faq2-question2 thq-body-large">
                  {props.faq3Question ?? (
                    <Fragment>
                      <span className="faq141-text27">
                        How will I receive updates about upcoming events?
                      </span>
                    </Fragment>
                  )}
                </p>
                <div className="faq141-icons-container3">
                  {!faq3Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon18">
                        <path d="M316 366l196 196 196-196 60 60-256 256-256-256z"></path>
                      </svg>
                    </div>
                  )}
                  {faq3Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon20">
                        <path d="M316 658l-60-60 256-256 256 256-60 60-196-196z"></path>
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              {faq3Visible && (
                <div className="faq141-container19">
                  <span className="thq-body-small">
                  You will receive updates through email notifications, so make sure to check the inbox of the email you registered with. Additionally, keep an eye on the campus website's event page or follow the official social media channels for the latest announcements.
                  </span>
                </div>
              )}
            </div>
            <div className="thq-divider-horizontal"></div>
            <div className="faq141-faq4">
              <div
                onClick={() => setFaq4Visible(!faq4Visible)}
                className="faq141-trigger4"
              >
                <p className="faq141-faq2-question3 thq-body-large">
                  {props.faq4Question ?? (
                    <Fragment>
                      <span className="faq141-text24">
                        Are there any fees for registering for campus events?
                      </span>
                    </Fragment>
                  )}
                </p>
                <div className="faq141-icons-container4">
                  {!faq4Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon22">
                        <path d="M316 366l196 196 196-196 60 60-256 256-256-256z"></path>
                      </svg>
                    </div>
                  )}
                  {faq4Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon24">
                        <path d="M316 658l-60-60 256-256 256 256-60 60-196-196z"></path>
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              {faq4Visible && (
                <div className="faq141-container22">
                  <span className="thq-body-small">
                  It depends on the event. Some events are free for all participants, while others may require a registration fee. Any applicable fees will be clearly mentioned on the event registration page. If you have questions, feel free to contact the events team at support@campusevents.com.

                  </span>
                </div>
              )}
            </div>
            <div className="thq-divider-horizontal"></div>
            <div className="faq141-faq5">
              <div
                onClick={() => setFaq5Visible(!faq5Visible)}
                className="faq141-trigger5"
              >
                <p className="faq141-faq1-question2 thq-body-large">
                  {props.faq5Question ?? (
                    <Fragment>
                      <span className="faq141-text22">
                        How can I provide feedback about an event I attended?
                      </span>
                    </Fragment>
                  )}
                </p>
                <div className="faq141-icons-container5">
                  {!faq5Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon26">
                        <path d="M316 366l196 196 196-196 60 60-256 256-256-256z"></path>
                      </svg>
                    </div>
                  )}
                  {faq5Visible && (
                    <div>
                      <svg viewBox="0 0 1024 1024" className="faq141-icon28">
                        <path d="M316 658l-60-60 256-256 256 256-60 60-196-196z"></path>
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              {faq5Visible && (
                <div className="faq141-container25">
                  <span className="thq-body-small">
                  You can share your feedback by filling out the event feedback form, which will be emailed to all participants after the event concludes.
                  </span>
                </div>
              )}
            </div>
            <div className="thq-divider-horizontal"></div>
          </div>
        </div>
        <div className="faq141-content1 thq-flex-column">
          <div className="faq141-content2">
            <h2 className="faq141-text18 thq-heading-2">
              {props.heading2 ?? (
                <Fragment>
                  <span className="faq141-text28">Still have a question?</span>
                </Fragment>
              )}
            </h2>
            <span className="faq141-text19 thq-body-large">
              {props.content2 ?? (
                <Fragment>
                  <span className="faq141-text23">
                  If your question isn’t covered here, feel free to contact the campus events team at support@campusevents.com. You can also explore the campus website or connect with us on social media for more information.

                    <span
                      dangerouslySetInnerHTML={{
                        __html: ' ',
                      }}
                    />
                  </span>
                </Fragment>
              )}
            </span>
          </div>
          <button type="button"className="thq-button-filled"
            onClick={() =>window.location.href ="mailto:Samkaushal580@gmail.com?subject=Event Inquiry&body=Hello, my email is Samkaushal580@gmail.com how may i help u "}><span>Email us</span>
            </button>
        </div>
      </div>
    </div>
  )
}

FAQ141.defaultProps = {
  action1: undefined,
  faq5Question: undefined,
  content2: undefined,
  faq4Question: undefined,
  faq2Question: undefined,
  action2: undefined,
  faq3Question: undefined,
  heading2: undefined,
  heading1: undefined,
  faq1Question: undefined,
  content1: undefined,
}

FAQ141.propTypes = {
  action1: PropTypes.element,
  faq5Question: PropTypes.element,
  content2: PropTypes.element,
  faq4Question: PropTypes.element,
  faq2Question: PropTypes.element,
  action2: PropTypes.element,
  faq3Question: PropTypes.element,
  heading2: PropTypes.element,
  heading1: PropTypes.element,
  faq1Question: PropTypes.element,
  content1: PropTypes.element,
}

export default FAQ141
