import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom'; // Import Link for routing
import './cta.css';

const CTA = (props) => {
  return (
    <div className="thq-section-padding">
      <div className="thq-section-max-width">
        <div className="cta-accent2-bg">
          <div className="cta-accent1-bg">
            <div className="cta-container2">
              <div className="cta-content">
                <span className="thq-heading-2">{props.heading1}</span>
                <p className="thq-body-large">{props.content1}</p>
              </div>
              <div className="cta-actions">
                {/* Register Now Button Redirects to /registration */}
                <Link to="/register" className="thq-button-filled cta-button" style={{ textDecoration: 'none' }}>
                  {props.action1}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

CTA.defaultProps = {
  action1: 'Register Now',
  heading1: 'Register for Campus Events',
  content1: 'Sign up now to stay updated on all upcoming campus events, special lectures, and workshops.',
};

CTA.propTypes = {
  action1: PropTypes.string,
  heading1: PropTypes.string,
  content1: PropTypes.string,
};

export default CTA;