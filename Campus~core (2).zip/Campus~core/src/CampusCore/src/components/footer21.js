import React, { Fragment } from 'react'

import PropTypes from 'prop-types'

import './footer21.css'

const Footer21 = (props) => {
  return (
    <footer className="footer21-footer2 thq-section-padding">
      <div className="footer21-max-width thq-section-max-width">
        <div className="footer21-content4">
          <div className="footer21-links">
            <div className="footer21-column">
              <img
                alt={props.logoAlt}
                src={props.logoSrc}
                className="footer21-image1"
              />
            </div>
            <div className="footer21-container1">
              <div className="footer21-column1">
                <strong className="thq-body-large">
                  {props.column1Title ?? (
                    <Fragment>
                      <span className="footer21-text22">Quick Links</span>
                    </Fragment>
                  )}
                </strong>
                <div className="footer21-footer-links1">
                  <a
                    href="/"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link1 ?? (
                      <Fragment>
                        <span className="footer21-text13">Home</span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="/event"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link2 ?? (
                      <Fragment>
                        <span className="footer21-text15">Events</span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="/about"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link3 ?? (
                      <Fragment>
                        <span className="footer21-text26">Workshops</span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link4 ?? (
                      <Fragment>
                        <span className="footer21-text16">Lectures</span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="/about"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link5 ?? (
                      <Fragment>
                        <span className="footer21-text25">About Us</span>
                      </Fragment>
                    )}
                  </a>
                </div>
              </div>
              <div className="footer21-column2">
                <strong className="thq-body-large">
                  {props.column2Title ?? (
                    <Fragment>
                      <span className="footer21-text10">Contact Us</span>
                    </Fragment>
                  )}
                </strong>
                <div className="footer21-footer-links2">
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link6 ?? (
                      <Fragment>
                        <span className="footer21-text19">FAQs</span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link7 ?? (
                      <Fragment>
                        <span className="footer21-text20">Testimonials</span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link8 ?? (
                      <Fragment>
                        <span className="footer21-text24"></span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link9 ?? (
                      <Fragment>
                        <span className="footer21-text27"></span>
                      </Fragment>
                    )}
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="thq-body-small"
                  >
                    {props.link10 ?? (
                      <Fragment>
                        <span className="footer21-text14">Register Now</span>
                      </Fragment>
                    )}
                  </a>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <div className="footer21-credits1">
          <div className="thq-divider-horizontal"></div>
          <div className="footer21-row">
            <div className="footer21-credits2">
              <span className="thq-body-small"></span>
              <div className="footer21-footer-links3">
                <span className="thq-body-small">
                  {props.privacyLink ?? (
                    <Fragment>
                      <span className="footer21-text23"></span>
                    </Fragment>
                  )}
                </span>
                <span className="thq-body-small">
                  {props.termsLink ?? (
                    <Fragment>
                      <span className="footer21-text11"></span>
                    </Fragment>
                  )}
                </span>
                <span className="thq-body-small">
                  {props.cookiesLink ?? (
                    <Fragment>
                      <span className="footer21-text18"></span>
                    </Fragment>
                  )}
                </span>
              </div>
            </div>
            <div className="footer21-social-links">
  
             <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                <svg viewBox="0 0 877.7142857142857 1024" className="thq-icon-small">
                  <path d="M713.143 73.143c90.857 0 164.571 73.714 164.571 164.571v548.571c0 90.857-73.714 164.571-164.571 164.571h-107.429v-340h113.714l17.143-132.571h-130.857v-84.571c0-38.286 10.286-64 65.714-64l69.714-0.571v-118.286c-12-1.714-53.714-5.143-101.714-5.143-101.143 0-170.857 61.714-170.857 174.857v97.714h-114.286v132.571h114.286v340h-304c-90.857 0-164.571-73.714-164.571-164.571v-548.571c0-90.857 73.714-164.571 164.571-164.571h548.571z"></path>
                </svg>
              </a>

  
              <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 448 512"
                  className="thq-icon-small"
                  style={{ fill: 'black', width: '24px', height: '24px' }} >
                  <path d="M224.1 141c-63.6 0-114.1 50.5-114.1 114.1S160.5 369.2 224.1 369.2 338.2 318.7 338.2 255.1 287.7 141 224.1 141zm0 186.6c-40.1 0-72.6-32.5-72.6-72.6s32.5-72.6 72.6-72.6 72.6 32.5 72.6 72.6-32.5 72.6-72.6 72.6zm146.4-194.3c0 14.9-12.1 27-27 27-14.9 0-27-12.1-27-27s12.1-27 27-27c14.9 0 27 12.1 27 27zm76.1 27.2c-1.7-35.3-9.9-66.7-36.2-92.9S405.2 30.6 369.8 28.9c-36.5-2.1-146-2.1-182.6 0-35.3 1.7-66.7 9.9-92.9 36.2S30.6 106.8 28.9 142.2c-2.1 36.5-2.1 146 0 182.6 1.7 35.3 9.9 66.7 36.2 92.9s57.6 34.5 92.9 36.2c36.5 2.1 146 2.1 182.6 0 35.3-1.7 66.7-9.9 92.9-36.2s34.5-57.6 36.2-92.9c2.1-36.5 2.1-146 0-182.6zM398.8 388c-7.8 19.6-22.9 35.6-42.5 42.5-29.4 11.7-99.2 9-132.3 9s-102.9 2.6-132.3-9c-19.6-7.8-35.6-22.9-42.5-42.5-11.7-29.4-9-99.2-9-132.3s-2.6-102.9 9-132.3c7.8-19.6 22.9-35.6 42.5-42.5 29.4-11.7 99.2-9 132.3-9s102.9-2.6 132.3 9c19.6 7.8 35.6 22.9 42.5 42.5 11.7 29.4 9 99.2 9 132.3s2.6 102.9-9 132.3z"></path>
                  </svg>
               </a>

  
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                  <svg viewBox="0 0 950.8571428571428 1024" className="thq-icon-small">
                   <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
                  </svg>
              </a>

  
               <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                   <svg viewBox="0 0 877.7142857142857 1024" className="thq-icon-small">
                     <path d="M135.429 808h132v-396.571h-132v396.571zM276 289.143c-0.571-38.857-28.571-68.571-73.714-68.571s-74.857 29.714-74.857 68.571c0 37.714 28.571 68.571 73.143 68.571h0.571c46.286 0 74.857-30.857 74.857-68.571zM610.286 808h132v-227.429c0-121.714-65.143-178.286-152-178.286-70.857 0-102.286 39.429-119.429 66.857h1.143v-57.714h-132s1.714 37.143 0 396.571v0h132v-221.714c0-11.429 0.571-23.429 4-32 9.714-23.429 31.429-48 68-48 47.429 0 66.286 36 66.286 89.714v212z"></path>
                    </svg>
                </a>

  
                <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
                  <svg viewBox="0 0 1024 1024" className="thq-icon-small">
                       <path d="M406.286 644.571l276.571-142.857-276.571-144.571v287.429zM512 152c215.429 0 358.286 10.286 358.286 10.286 20 2.286 64 2.286 102.857 43.429 0 0 31.429 30.857 40.571 101.714 10.857 82.857 10.286 165.714 10.286 165.714v77.714s0.571 82.857-10.286 165.714c-9.143 70.286-40.571 101.714-40.571 101.714-38.857 40.571-82.857 40.571-102.857 42.857 0 0-142.857 10.857-358.286 10.857v0c-266.286-2.286-348-10.286-348-10.286-22.857-4-74.286-2.857-113.143-43.429 0 0-31.429-31.429-40.571-101.714-10.857-82.857-10.286-165.714-10.286-165.714v-77.714s-0.571-82.857 10.286-165.714c9.143-70.857 40.571-101.714 40.571-101.714 38.857-41.143 82.857-41.143 102.857-43.429 0 0 142.857-10.286 358.286-10.286v0z"></path>
                    </svg>
                  </a>
              </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

Footer21.defaultProps = {
  column2Title: undefined,
  termsLink: undefined,
  action1: undefined,
  link1: undefined,
  link10: undefined,
  link2: undefined,
  link4: undefined,
  content1: undefined,
  cookiesLink: undefined,
  link6: undefined,
  link7: undefined,
  logoAlt: 'University Campus Registration System',
  content2: undefined,
  logoSrc: 'https://i.imgur.com/ksjjhUR.png',
  column1Title: undefined,
  privacyLink: undefined,
  link8: undefined,
  link5: undefined,
  link3: undefined,
  link9: undefined,
}

Footer21.propTypes = {
  column2Title: PropTypes.element,
  termsLink: PropTypes.element,
  action1: PropTypes.element,
  link1: PropTypes.element,
  link10: PropTypes.element,
  link2: PropTypes.element,
  link4: PropTypes.element,
  content1: PropTypes.element,
  cookiesLink: PropTypes.element,
  link6: PropTypes.element,
  link7: PropTypes.element,
  logoAlt: PropTypes.string,
  content2: PropTypes.element,
  logoSrc: PropTypes.string,
  column1Title: PropTypes.element,
  privacyLink: PropTypes.element,
  link8: PropTypes.element,
  link5: PropTypes.element,
  link3: PropTypes.element,
  link9: PropTypes.element,
}

export default Footer21
