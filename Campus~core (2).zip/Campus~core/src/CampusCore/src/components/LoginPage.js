import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import axios from "axios"; // ✅ Import axios for API requests
import "./LoginPage.css";
import userIcon from "../views/OIP.jpeg"; // Ensure correct image path

const LoginPage = () => {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (event) => {
    event.preventDefault();
    setLoading(true);
    setErrorMessage("");

    if (!credentials.email || !credentials.password) {
      setErrorMessage("Email and password are required.");
      setLoading(false);
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/login", // ✅ Connects to backend API
        {
          email: credentials.email,
          password: credentials.password,
        },
        {
          headers: { "Content-Type": "application/json" },
        }
      );

      if (response.status === 200 && response.data.token) {
        sessionStorage.setItem("token", response.data.token); // ✅ Use sessionStorage for security
        sessionStorage.setItem("role", response.data.role); // ✅ Store user role

        // ✅ Redirect based on role
        if (response.data.role === "admin") {
          navigate("/profile");  
        } else {
          navigate("/profile");  
        }
      } else {
        setErrorMessage(response.data.message || "Invalid credentials.");
      }
    } catch (err) {
      const errorMsg = err.response?.data?.message || "Network error. Please try again.";
      setErrorMessage(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <motion.div
        className="login-container"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="login-content">
          <div className="login-image">
            <img src={userIcon} alt="User Icon" className="profile-image" />
          </div>

          <div className="login-form">
            <h2 className="login-title">Login to Your Account</h2>

            <form onSubmit={handleLogin}>
              <div className="input-group">
                <input
                  type="email"
                  placeholder="Email"
                  value={credentials.email}
                  onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
                  required
                  className="login-input"
                />
              </div>

              <div className="input-group">
                <input
                  type="password"
                  placeholder="Password"
                  value={credentials.password}
                  onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                  required
                  className="login-input"
                />
              </div>

              <button type="submit" className="login-button" disabled={loading}>
                {loading ? "Logging in..." : "Login"}
              </button>
            </form>

            {errorMessage && <div className="error-message">{errorMessage}</div>}

            <div className="login-links">
              <Link to="/forgot-password" className="forgot-link">Forgot Password?</Link>
              <Link to="/register" className="register-link">Register</Link>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;