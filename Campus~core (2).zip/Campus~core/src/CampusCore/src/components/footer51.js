import React, { Fragment } from 'react'

import PropTypes from 'prop-types'

import './footer51.css'

const Footer51 = (props) => {
  return (
    <footer className="footer51-footer8 thq-section-padding">
      <div className="footer51-max-width thq-section-max-width">
        <div className="footer51-content">
          <div className="footer51-column">
            <div className="footer51-logo1">
              <img
                alt={props.logoAlt}
                src={props.logoSrc}
                className="footer51-logo2"
              />
              <div className="footer51-links">
                <a
                  href="https://example.com"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="thq-body-small"
                >
                  {props.link1 ?? (
                    <Fragment>
                      <span className="footer51-text4">Events</span>
                    </Fragment>
                  )}
                </a>
                <a
                  href="https://example.com"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="thq-body-small"
                >
                  {props.link4 ?? (
                    <Fragment>
                      <span className="footer51-text6">Contact Us</span>
                    </Fragment>
                  )}
                </a>
                <a
                  href="https://example.com"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="thq-body-small"
                >
                  {props.link5 ?? (
                    <Fragment>
                      <span className="footer51-text1">FAQs</span>
                    </Fragment>
                  )}
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="footer51-credits">
          <div className="thq-divider-horizontal"></div>
          <div className="footer51-row">
            <div className="footer51-footer-links">
              <span className="thq-body-small">
                {props.privacyLink ?? (
                  <Fragment>
                    <span className="footer51-text5"></span>
                  </Fragment>
                )}
              </span>
              <span className="thq-body-small">
                {props.termsLink ?? (
                  <Fragment>
                    <span className="footer51-text7"></span>
                  </Fragment>
                )}
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

Footer51.defaultProps = {
  link5: undefined,
  action1: undefined,
  content1: undefined,
  logoSrc: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAV4AAAFeCAYAAADNK3caAAAAAXNSR0IArs4c6QAAIABJREFUeF7tnQeYG9W5hr+tkta7694rmBAgQACbUAIOPXQI4QbTwWBCS4W0m56bhPRC6DWACeVSklACcagBHAjFMb04YNwL7vZqV9rVvd/YsxnJkqZodDQrfed59oHHmjnlPb8+/fOf/5ypy2QyGaiIgAiIgAgYI1An4TXGWg2JgAiIgEVAwitDEAEREAHDBCS8hoGrOREQARGQ8MoGREAERMAwAQmvYeBqTgREQAQkvLIBERABETBMQMJrGLiaEwEREAEJr2xABERABAwTkPAaBq7mREAEREDCKxsQAREQAcMEJLyGgas5ERABEZDwygZEQAREwDABCa9h4GpOBERABCS8sgEREAERMExAwmsYuJoTAREQAQmvbEAEREAEDBOQ8BoGruZEQAREQMIrGxABERABwwQkvIaBqzkREAERkPDKBkRABETAMAEJr2Hgak4EREAEJLyyAREQAREwTEDCaxi4mhMBERABCa9sQAREQAQME5DwGgau5kRABERAwisbEAEREAHDBCS8hoGrOREQARGQ8MoGREAERMAwAQmvYeBqTgREQAQkvLIBERABETBMQMJrGLiaEwEREAEJr2xABERABAwTkPAaBq7mREAEREDCKxsQAREQAcMEJLyGgas5ERABEZDwygZEQAREwDABCa9h4GpOBERABCS8sgEREAERMExAwmsYuJoTAREQAQmvbEAEREAEDBOQ8BoGruZEQAREQMIrGxABERABwwQkvIaBqzkREAERkPDKBkRABETAMAEJr2Hgak4EREAEJLyyAREQAREwTEDCaxi4mhMBERABCa9sQAREQAQME5DwGgau5kRABERAwisbEAEREAHDBCS8hoGrOREQARGQ8MoGREAERMAwAQmvYeBqTgREQAQkvLIBERABETBMQMJrGLiaEwEREAEJr2xABERABAwTkPAaBq7mREAEREDCKxsQAREQAcMEJLyGgas5ERABEZDwygZEQAREwDABCa9h4GpOBERABCS8sgEREAERMExAwmsYuJoTAREQAQmvbEAEREAEDBOQ8BoGruZEQAREQMIrG4g0gczatehetBiZ9RuArk5k1q1HpqsL/Hek00BzM+r419Zm/Rexzf/f1or6wUNQ19ov0uNT52qTgIS3Nuc9sqPOdHaiZ+Ei9CxZYv23e968/whv52bhTW0W3tRm4bXFlsJrizCFd/RoNIwfh4atJqBh/HiJcGRnvfY6JuGtvTmP5Ih7FixE+u230f3uPHS/+Vav8PasWhW4v3WxGOqGDN4kvNtuKxEOTFI3hk1Awhs2UdXniwAFN/XCi0g//6IlvD2LN4cVfNXifrFThJsmT0LTXnuiYdxYy0NWEQHTBCS8pomrPYsAY7SpOS8j9dgTSM16Fj1LlxojUz90KJp2n4TGPfdA4047omHEcAmwMfpqiAQkvLIDowQYw+1+/Q1LbLuemYXud+YCXV1G+2AZfiyG+tGjLOFtnLQbmibvhvrhw433Qw3WJgEJb23Oe0VGTS+36+9Po+uBB5F+9bVNmQoVLrYAM/zQ/MlD0LjDdvJ+KzwntdC8hLcWZjkCY2Qst+uxx9F53wPonvvvCPQouwsU4MY9dkf8xKlo2mVniW/kZqi6OiThra75jORo0q+9bglu6om/G43l+oVhi2/zQQcq9OAXnq73RUDC6wuXLvZDwI7nJv/3bqSeejoSoQW3/tuhh+bDDkXsiEMV93UDps8DEZDwBsKmm7wQSL80G8k/3IHUc8/1CdF1jql+zGjEjjla4utlonWNbwISXt/IdIMXAgwvJG+9rc94uvnG1DBxa8RPOQnNB+yvXW9eJl3XeCYg4fWMShd6JcCFtI5bbkXXQw/3OU/XOUYr5rvLRxE/eSqadp+sBTevBqDrXAlIeF0R6QI/BJgylrznT+i8866yLaRREK0zGWLNyGQy1sE55coFthfcEmeejsadd/KDQteKQEECEl4ZR2gErDzdvz2K5O13hpoyZi94WectjBxunURmn0pmC29m3ToglULPsuXWwTphbj1m+00HH4jEaaeA4QcVESiVgIS3VIK6v5dA6h/PouPq65Ce83LJVJw7y3jCWP2oUWj48LYFt/cygwJdKfQs3yS89mE76ZdfCcXzrmtvR/yMUxH/9HGK95Y8u6pAwisbCIUAvd2O39+CzrvvKSmu69xJ1rjbrmjcecdAKV328ZKp519AetY/kH75VZRy0hkhNe66CxLnTgd3uamIQCkEJLyl0NO9oXq71iP9lH3QfOABgQU3d0osAf73u+h86K/omvlISd4v+xc7aaq12FY/cKBmXwQCE5DwBkanG20CfLxP3jQDnffdH9jb5aN8074fR/zEE9C4/Xahw7W2LD8zC10PzwRT3YIuxjXusD0S552Dpr33Cr2PqrB2CEh4a2euyzbSrr/+DR3X3RB4QY3HNDYfuB9ix32qrItX9H7Tz/4TydtuR2r2nEDiS6+3+cjDkTj1ZNSPHVM2pqq4uglIeKt7fss+Onq7Hddej877HgwmZO3tiB1xGOIn/JcRIbPFt+PGmwIvAjaMGY3EBeeh+ZCDys5XDVQnAQlvdc6rsVF1PfF3S3h5xq7fwvBC80EHID71M2X1dPPFfRnvTd48I5CXTq83fuZp1klmepmm31nX9SQg4ZUdlESg44bfI3nTLYFiu82fmIL49Glliem6DarUjR5Ne+6BxGfP1qYKN9D6PC8BCa8MIzABK8xw2ZXovP9B33UwrpuYfhZiRx1esa24PBe44/ob0fXYE77DJFb/P3ceYkcc7nvsukEEJLyygcAEStkwETvqCCTOOtNIXLfQABnvDRpyULghsNnoRoUaZAOlEODpY8kbb/a9MYHbbhPnn4vm/aaU0nwo95ZyoE8lQyWhDF6VVIyAPN6Koe/bDZcSZogdfxwS004PtCMtbGqleL3Kbgh7NmqnPglv7cx1qCPlJoSOK69B6plZvuplJgMXpeLHHVux2G5uhwOPJRZD4gsXWqlwKiLgh4CE1w8tXdtLgG+X6LjqWvAsBD8liju/SjlnouWLn0P81JP9INC1IqB0MtlAMAJ8cSXzd9M+83e56SBx9jSjebteRpi86x4kb7jJ91kOEl4vdHVNLgF5vLKJQAT41uDk9Teie/4CX/fHTz7R2nwQtUNmgm57lvD6mn5dvJmAhFemEIgAMxo6brwZmVWrfN2fOO+zSJx2cmTiu3bng6bGSXh9Tb8ulvDKBkohEHTHWlSFKugCW1THU8rc6t7yE5DHW37GVdkCMxo6bp7ha8cXNx1ENQuAu9g2XnEVUo8/6Wu+JLy+cOliebyygVIIVJvwyuMtxRp0r18C8nj9EtP1FoFqi/EGTY+Tx6svRBACEt4g1HQPgqZfRTWrIWh6nIRXX4YgBCS8QajpHgRNv4pqHm/nXfegQ3m8smxDBCS8hkBXWzNBY6JR3LnGuQkSs+Z98nirzbLNjEfCa4Zz1bUS9JCcKJ5jW01jqTpDq9IBSXirdGLLPSye6sWzGpK33+k7pSxqr80J+voivYWi3FZWvfVLeKt3bss+sqCZDY277oLEudPRNHlS2fvo1kApB+RE6XhLt3Hq82gRkPBGaz76VG+CbrPlRorYSVMRP3lqxc9sCDoGTlRUtz/3KSOq0c5KeGt04sMYdtDYKNuOwiIb+5+8aQY677vf98s6oxirDmNOVYcZAhJeM5yrshXGefnqn+Rtt/sWLnq9zUcejsSpJ1fkvWvWmyfufxDJW271fcIaJ1Px3ao0aWODkvAaQ12dDQXN5yUNeo2xY49G7FNHG38NUNCdavYsRnUjSHVaWfWNSsJbfXNqdETWK9KvuApdPg+XsTtZP2Y0YsccjdgRhxoTX+Ygc2Ew9dTTvj11+wdDr3Y3amZV15iEt+qm1OyASgk32D3lW4djRx+J5oMPLKv4sq/dr7+B5P/eHVh0FWYwa1/V2pqEt1pn1uC4gubB2l1kvLd+9Cg0H3Zo2Txfim762X8iefe9SM+eHcjTVZjBoFFVeVMS3iqfYBPD61mwEBsvv9I6v6GUwrBD8957oWn/T6Bxhx1Q19qvlOp672X/up6Zha6HZ4JhBnR1Ba5X2QyB0elGBwEJr8yhZAJhhBuc3m/D9tuheb8paNprTzSMGxv4NUEU3NQLLyL9/IvWf3uWLi15rM2fmIL49Glo3H67kutSBbVLQMJbu3Mf6shL2YiQryP0LBt32hEN226DhgkT0DBhPOpHjnT1grkTrXvRYnS/+Vaogmv3MTHtDMRPP9W1H6HCVWVVR0DCW3VTWpkBlbKZoliP7fhvw/jxqN9qAhpGDEddWxvqmpuBWDOQySCzbj0yXV2g6PYsXrxJeN94KxQP19k3hRkqY1vV2KqEtxpntQJjYrih8w93WGlaPT7fPOy1uxThurbW/wgvxdcW3tQm4c2s3+C1Ot/XRfUsYd8D0Q0VJyDhrfgUVE8Hgp7R2xcIWN7u9LMQO+rwwDHnvjBO9dEMAQmvGc410UqYi2xRA6YtwlGbkb7dHwlv356/yPW+1JzeyA1oc4e0RTiqM9M3+yXh7ZvzFtleh5XTG6UBalEtSrNRHX2R8FbHPEZmFNYi2933IjnjttCzCio1SC2qVYp89bYr4a3eua3YyEo9OKdiHc/TsBbVojQb1dMXCW/1zGVkRlJNi2zaqRYZs6qqjkh4q2o6ozOYsHeyVWJkde3tiJ9xKuKfPk471SoxAVXcpoS3iie3kkMr5SWSley3s+0ovZQzKkzUj3AISHjD4aha8hDo66llSiGTWZeLgIS3XGRVL5ha1nHdDeh8eGZJRzFWAiWPqGy54Dwwo0FFBMImIOENm6jq6yVgvVBy5iNI3jwDzHToSyV2/HFITDu9rG/E6Es81NdwCUh4w+Wp2nII9MUNFdowITMuNwEJb7kJ13j9fXFDhTZM1LjRGhi+hNcA5Fpvoi9tqNCGiVq3VjPjl/Ca4VzTrZg4qzcswNowERZJ1VOMgIRX9mGEQF84q5febvz0UxA76khtmDBiFbXbiIS3dufe6Mj7wjZiebtGTaKmG5Pw1vT0mx18+qXZ6LjqWqSef8Fswx5a0/ZgD5B0SWgEJLyhoVRFbgSi7PXqDRNus6fPwyQg4Q2TpupyJRDFw3Pk7bpOmy4ImYCEN2Sgqq44gSgeniNvV1ZrmoCE1zRxtYcoeb3ydmWQlSAg4a0E9RpvM0per7zdGjfGCg1fwlsh8LXebBS8Xnm7tW6FlRu/hLdy7Gu65Sh4vfJ2a9oEKzp4CW9F8dd245X0euXt1rbtVXr0Et5Kz0ANt19Jr1febg0bXgSGLuGNwCTUchcq4fXK261li4vG2CW80ZiHmu1FJbxeebs1a26RGbiENzJTUbsdMen1ytutXTuL0sglvFGajRrti0mvV95ujRpZxIYt4Y3YhNRqd0ycXCZvt1atK3rjlvBGb05qskcmTi6Tt1uTphXJQUt4IzktEe9Uajnw/g+B9Cr/Ha1rAOITgVEXAI0Ds+4vp9db0NvtXg+suBdYPdP/WHhH0yBg1Oc2jUlFBDwSkPB6BKXLHAR6NgIrHwAW/iaA+NYBsVHAuO8D7XtnYS3nu9kKertdi4F3LgA63vA/xQ2twJATgJHnAg39/N+vO2qWgIS3Zqfe28DTPRksS3ZjVEuj44bMJsFdfhew7Cb/4lsfB/ofAIz75pZe72uvo+PKa5B6Zpa3Dnq4quC71OjtLr8dWHQZkOnyUJPjkrpmoH0vYPz3gaZh2T8gmQzq6ur81aera4qAhLemptv/YFf8v+he89oaHD2hFTsOana6vUDnAmDh74BVD/isuA5oHg6MvggYdETZvd6C71Jj/988BUgt89d/hksS2wFb/QyIb5V1bzqdxsqVKzFgwAA0Nzt5+WtCV1c3AQlvdc9vSaNL9WTw9JIkTnt0CQ4cncDv9hmO1iaHJ5dJAxtfAd77NpCc66+t+hjQvu8mjzE31hui11vc270NWPhrf/3m1Y2DgbH/DQw6LOve7u5ufPDBB1i+fDmGDBmC4cOH+69bd9QEAQlvTUxzsEF+kOzG955fictfXY0RLY246KMDcNHO2Qti1iP62n8A733DZ8jBxeu9+14kZ9yGnqVLg3V+813NhxyExNnT0DBx6+x6gnq7BeK6mUwGa9euxfvvv49UKoWWlhZMnDgRTU1NJfVfN1cnAQlvdc5ryaNibPefyztxzEOLsDzZjYY6YNsBzbjkY4NxzITW7PqDLrbVNQL9PgpMvHQLr7d77r/RccVV6Hr8ycBjobebmH4WYkcdDjgf+63YbgBvt0hct7OzE/PmzcO6deus/jY2NmLkyJEYNiw7/ht4MLqxqghIeKtqOsMbzMrOblzy0ir84l//SRlrqq/D5KExXLHvMOwyOOZoLAN0LQUW/NJ/vNd6bP963lhv1/0PInnLreievyDQwPJ6u5luYONrwNzP+YvtusR1Fy9ejBUrVqCnp8fqKxfX6PVus802lgiriICTgIRX9rAFge4M8K8Pkjj8wUVY2tGd9XlLYx2OndCKy/cdhgHN9f/5LGi8t4jX27NgITquuwGdD88EuvxlHdSPGW2FGGKfPDjH210HLL0FWHyZv5kvEtel4C5ZsgRcWHMWCu6YMWMwePBgf23p6qonIOGt+in2P8DVnT341ZxV+J8XV25xM5fWhiYa8MWdBuIbu4YU7y3m9c58BMmbZ4ChBz8ldvxxSEw7HfXOBa6g3m6BuC69W2dcN7d/9HpbW1utWG9DQ4Of7uvaKicg4a3yCfY7vJ4M8OaaLhz2wELMW5/twdl1Md67Tf9m/HD3wTh+6xDivW5e7y23ouuhh5FZv8HTcLiQljj/XDTvNyX7+u4A3m6BuC4X05LJpBXX3bChcL+4uEavd9CgQZ76rotqg4CEtzbm2fMo13b14IrX1uCbz60ARbhQYbx3tyExXLbPUEweGndcFjDeW8TrTT37TyRvvAnpOS+7jqMuFkPspKmInzwV9QMdHnkQb9clrrtgwQIrZ5ciXKjQ621ra7NivdpU4Tp9NXOBhLdmptrbQN9dl8YRf1mI11e5x1QTDXU4fFw/XDllGIbGHY/SjPd2vAUsvtr7GQhFvF4/x0Y27roLEudOR9PkSdkDTq8GFl0OLL/VGwheVSSuy1xdxnWZu+tW6PWOGzfO2lShIgIkIOGVHfQSWJfqwQ1vrMXF/1gBppO5FcZ7B8cbcOGOA/DdSTmP0hTfDf8C5n7ee35vQxsw7JRNh87kFC8H6BQ8CMfydl8F3jnPe18a+wMjpm86i8FxDgPjuqtXrwa9Xebrein19fVob2+3Yr0qIiDhlQ1kEZi/Po1jHl6El1Z0eiZTXwdMbG/CD3YfgqkTS4331gOJicDWv9ritC8vB+gUPAgn/QEw/xJg5YPexlWfAAYeCoy5OCu/mCGFjRs3WnHdjo4Ob3Vtvorbh8ePH28JsIoIyOOVDVgE1qd6MOPtdfjCM8vRxXwyH6Wxvg67Do7h0o8PxZ7DS4z3WqJ3CDDmq762EhfcGmztrHsaePerQLeHxTkrrrs9sPWvgdjoLAr0cOfPn295vMXiuvnQ0etlqGGrrbLPdvCBWZdWEQEJbxVNZilDWbAhjRNmLsYzS5OBqok31OHgsS24et/hGNlSSrw32FbigluDubHj3YuB9S+4j8s6K3gbYOzXgLY9s65nLHfp0qXWn71Jwr3C7CtisRgmTJhgpZip1DYBCW9tz781+g3pHtw5dz3O//syJH16uzY+xnsHxhpw3kf6W2lmWcVvvLfIATrWVuLrb0TXY0/0bqoovFnC57GP1mLaN4CBBwFMI9tcKLSrVq2y4rq5myT8mA+9XqaVMeSgUtsEJLy1Pf/W6BdtSOPUR5fg0UX+4pa56Bjv3aqtCd+bPAinfCgnlun1PAeGGto/DrR9DBj6mSwBZHuM9aZnz0H6tdeBVBeQASi8TZN3y94swYvZ5upHgDVPAhvfKH6CWpHDb5in+95774HnMZRa5PWWSrA67pfwVsc8Bh5FRzqDe99bj3OeWIoNaX+x3XyNMt6786Bm/Gbvodh3ZMJxSZH8Xkts9wZaPgK07QE0DQaY4ZBzXKT/QfYA6XUAN05wgW3d85uyG9Y9m53dUOTwG8Z1uZi2Zs0a/83nuYNeL4+MHDt2bCj1qZK+SUDC2zfnLbReL96YxjlPLsP98zwsPHlsNdZQh/1GJXDtlGEY2+o4FtGZ37v2qc1iu92mxazENiGJbaFO2iK8dtOBPkx1owivfx5oGp73UHPGdZmru2zZssBx3Xy9icfj1iIbD9FRqU0CEt7anHdr1IznPvD+Bpz52FIwhzfM0r+5Hufs0B8/22NIdrUU3875QPLdzWLbCvAx3xFTDbMf+etyiHDqAyCT3GIxjXFd7kpbuHBhSXHdfO3z3AZ6vdxKrFKbBCS8tTnv1qh58tiFTy3HXf/edIZsmIXx3vGtTfj2pEE488O5uasZIJNyFdtMphsbupZhZcdbGN66C2Lc1OBSUt0bsWjtsxiYmIj2+Di3yxk13qIvTBXjuboMMXT5PBXNQ4PW1mHb600knOEYL3frmmogIOGthlkMMIbO7gxmLtyIUx5ZgjVd4Xq7jXV1GNfWiINGt+CEia04YLT3R2pbbJesfwGrN861RDfd3YFBLdtizIB9MKb/PgVH25lejTmLbsDS9bMRa2xHe2ycdd/wtt08ivB/qqbg8jU+FGBumvCyNdjPNNDr5SHpo0aN8nObrq0SAhLeKplIv8NY1tGNi2etwC1vr/V7a97r6eEOTzRasd1PjExYB+fw+MjBsXr0a3Kc21ugtZ5MCis3voXFa5/D4nXPozO1GqmeDaAHC9ShsT6GttgYfHjYf2V5s06hXrnhDSxY81TvPQ31zWhuaEOiaZBvEabXS7Fl+hgX2CjA/GOGg9/NE4UA09vlNmJmOqjUFgEJb23NtzXarp4MnljUgRP+thirOoN7u8zdZSx3/9EtltjuNTxuHZbD8xvanYekF2Bsi+aitf/A/NVPItW9Hsn0anSm82cQ1Nc1INE01PJm+zWPQAY9lkCnM505Qp3bYB2cItw/PgHD2yZ5DkfYIkwBpidMAV6/fn3R4yC9mBW93hEjRlh/KrVFQMJbW/NtjZavbP/v51bg2teDebuJxjpLaPcb1YKPj4hjRKIRQxIN2W+k8CC2C1b/3RLNZGolOrjI5bnUoaGuCRlKL2PFvsom7znWOMAS8CAiTC+Yf8zrtUWY4Qi/hbFe2+vVq+D90uvb10t4+/b8+e49X9k+a0kHjpu5BHyLsNfCLcF7DIvjE6MS+PiIBMa3bhLbQbEGOF74nrc627NdvO6fWLbuJWxILQsgtl576ue6LUV4RPvunhfy6AnboQgeik4vmELM//da9FJMr6Sq6zoJb3XNp+toKLY/eOEDXPqK+4YA5uN+dHDMitvuMyJhnULGUMLAeD24gFas5BfbVVYYwb+X6jqsEC7YJMLxxoGINw1CW2w0RvXfs+hinrNRpp/ZnjBPLrPjwW4ibL8UU6+CD2EK+1AVEt4+NFmldpUb015YnsRRf9n0yvZ8hW+W2G5AsyW2+46MY/sBMQyJN2BQvB7NXEErUvJlJCRTURbbQoPZJMKJpiEY1PIhtDQPx8i23TG0dSdPU2CLMGPCFGF6wvwrtOWYXi+zG4YOHeqpfl3U9wlIePv+HHoeARfSfjp7FX46O/slltzmO6F1U0bClFEt1pZfii0XyRhi8Cu22RkJnrsXwQu5KNeEhvo4Ek2DMTA+EQNaJmJQYttAIsyMCFuEnYeo61XwEZz6MndJwltmwFGpni+UmLOy03plO7cJU09HtjRaMVsulE0aGu8V236NblFbIN2TxNJ1L2LlxjfzpH9FZdRh9sPOjGhFc2N7IBF2pqfZIsz/UoT1Kvgw5yr6dUl4oz9HofRwdVcPLn15NS59ZfXmjISEdWg5PVv+tXnItc1N/2LqF1PACqV/hdLxSFaypQj73aiRT4Q5VL0eKJITHnqnJLyhI41mhXx78J/nbbAWyIYlNoktc3DdilNsg6d/ubXSlz/PzhEOslvOXpRjloS2EPdlW/Dedwmvd1Z9+kqeb86twYNiEtvyTWTpIly+vqnmKBGQ8EZpNirYl+jm2lYQSklNl7ZbrqSmdXPkCUh4Iz9F5etg38u1LR+L8tZc2m658vZNtVeCgIS3EtQj02YG6Z5OJNObc217/G6/jcxA+k5H6urQWBdDrGkAmhr6oane+8ltfWeQ6qkbAQmvGyF9LgIiIAIhE5DwhgxU1YmACIiAGwEJrxshfS4CIiACIROQ8IYMVNWJgAiIgBsBCa8bIX0uAiIgAiETkPCGDFTViYAIiIAbAQmvGyF9LgIiIAIhE5DwhgxU1YmACIiAGwEJrxshfS4CIiACIROQ8IYMVNWJgAiIgBsBCa8bIX0uAiIgAiETkPCGDFTViYAIiIAbAQmvGyF9LgIiIAIhE5DwhgxU1YmACIiAGwEJrxshfS4CIiACIROQ8IYMVNWJgAiIgBsBCa8bIX0uAiIgAiETkPCGDFTViYAIiIAbAQmvGyF9LgIiIAIhE5DwhgxU1YmACIiAGwEJrxshfS4CIiACIROQ8IYMVNWJgAiIgBsBCa8bIX0uAiIgAiETkPCGDFTViYAIiIAbAQmvGyF9LgIiIAIhE5DwhgxU1YmACIiAGwEJrxshfS4CIiACIROQ8IYMVNWJgAiIgBsBCa8bIZ+fr1+/Ho2NjYjH4z7vdL+8u7sb69atQ//+/VFXV+d+g64QAQeBVCqFlStXoqenJy+XtrY2tLa2ipkBAhUVXgrJc889h9///vfWf9PpdOAhH3HEEfjJT37i6f5kMoknn3wSf/nLX/D8889j9erVnu7jRVOmTMG3v/1tjBgxIuueTCaDSy+9FN/73vesf+d/P//5z4fI4u36AAASXUlEQVQmkC+88AJOPPFELF68GHvvvbfFbOTIkQX7PX/+fOuav/71r77GN2zYMBx99NH4zGc+U7D+ZcuW4bTTTsPChQt72//Nb36DAw880DNH54XXXnutxc4ukyZNwhVXXIGWlpa89XFs99xzD/785z+DfQlS2tvbcfXVV2PHHXcMcnvge0zaPG2S9n355Zfj4YcfBp0Ct0LmH/nIR3DhhRfiqKOOQlNTU9FbOJ6bbroJV111FTo6Otyqd/2cc3/BBRdg8uTJeb87/PGgbdC2S9ELZ0dGjx6Nm2++GbR9U6ViwrtmzRprcv/4xz+GMlaK0jXXXFO0LorWz372M/zhD3/Axo0bA7d7/PHHW205jfKNN96wDHXJkiVWvQMHDsTdd9+N3XffPXA79o38wpxwwgnWj4VdfvSjH1nCnltomL/85S/x05/+tCTDpNd+1lln4fvf/z769euX1Qw5fvKTn8S7777b+++33347+OMXpPzqV7/Cd7/73d5b+eN2xx13bOF98Yv9wx/+0Prilfql4/zce++94BfdVDFp8/PmzcP06dMxa9aswMP70Ic+ZNnSfvvtV9CB4A/7SSedhM7OzsDt5N7Y0NCA888/37K9XOGn4H7xi18EBT+sstVWW1k/TMUcmbDasuupiPBSHPilpuGHVYoJL3/577rrLlx00UVYtWpVyU3mEwZ6pJ/61Key6j/ssMMsbyCRSJTUJn8oaIhOY6NRfvnLX86ql+Ok58nPwjLM/fffH7fccosV3rBLJYSXNvOlL33J4hlGMS28Jm3+kUcewTnnnBP4acDJlz/AxZ7ecn80w5gb1kHxpR1/4QtfyKqS3wPaY5ilZoSXXu7ZZ58d6q9kIeEthxh5Fd5YLIbrrrsOxx57bGA74WM173/rrbey6sgnvPnEP3DDjhvPO+88y4O248qVEN7f/va3llcc1g+KaeE1ZfMMLfDpKGgIJp+9MPzAUAIdi9xSLuFlOwwD3XfffRgyZEhvs/xBue2228Iw6946akJ4+ct/5pln4k9/+lPvwBnQP+igg7K8Kr9kGRM644wztriNj8AUjnyPpoMGDcJee+2VNbH52n3llVdAUbOLV+Hl9TvttJMVTgkSP+KPxg9+8AP84he/2KJb+YQ390tAr4FxVz+PUHPmzAH/nALHRRc+neyxxx5WP0wL79KlS62482uvvdbLgZ4YY9380gQpfAphqGv8+PFBbvd1jymbZ0jqlFNOAT1eZxkwYIC1PnD66aeDNl+o8P5HH33Uigk7w0i8njZEO95hhx2ybs+1OV53wAEHWAvMfgvtin23bY/9pt3xu22XXOGdOHEi9tlnH79NZV3PH2E+DbM9U8V4qGHFihVWLJRiZhfGXSmOYRd+UektckKdhRP54x//GB/72MesRxq34iUGWczbzCeSbm3y85deegmMJ+fzXvLVmWuUxxxzDG688UbXBRJnXyj2jE1zgcMZB//sZz/b+wNgWniffvppfPrTn8aGDRusrnLOfve731ki0xeyO0zZ/J133mmFGJw/mhQl2kDuYnAx+2MsnfZFL9dZF2PGjPk6mXv5bnixdV7jxa5ybdzL2o7X9k1eZ1x4vcANAwC9DMaHnPEgfmEvvvhifO1rX/MlRl6Mq5jwjhs3zlqB56+z1+IWE/QivEGNkm3TwBkXtwsXoejx0CsIew7d+D7wwAOYOnVqb1/opXIxhKvRfaGEzSvfmPN51dtss401Z0G8+nz2t/XWW+PBBx/M4u42d37mxwsnCa8foo5rvcANWHXWba+++qr1eOr0Fk8++WTLU3JLkclt34txucVXp02bZnmMXtvmIxdXiwtlX5RTeDl+fmFPPfXUXhTOOFjYc+jGN1d4nT8CYdhKuesIm1e+/jIcc+ihh+Kdd97p/bjUJ8ncJw2uWTDbxJk26DZ3fth64STh9UO0AsLLRS2ugtuFMVZ6ncxR9Fu8GJeb8DJOykdBL/Eoph3Rw3vqqacKdrXcwstFGi6m2DnOURLeUubS79yHcb0XQSm1nVz7yxcf9dtGvhDJr3/9a2th3C5evhte2/XCScLrlWbOdV7gBqy69zbGKWkcFDq7BIl3+jEuN+FlXV7Ty7ih4Ctf+UrRFfxyC2/ueCopvLk50mS56667WqlzXLz0+hThx64Y22QuLNciuKq/8847Y+jQoZ5iysxp5f32BhATNp87X4zpMiNgu+228zPsrGvz5Y/n2l2YwpvrYXtZXAsaTgsMJaQbqzLG68Vg/PDzYly5hs+VUj76UfztBQrGmJn8zxBCoZIvfWyXXXaxLp89e3bvbeUWXoY6mJZkJ8ZXUnjzxZz9zJ99LYWQLJmAf8ghh+RdWOXCEne0cREpd0cjs2+YBcOQFTcVDB48OKsb/MGnUHNnI//szRmVEN4wUqS8fI+8fDe8zBUXTpmV9NBDD/Veni+mXMjjDZLWFgYjL2PLd01VCm++RyQusgXNp/ViXPmE94YbbgB3mPGx3S7F0sv4xeXC35VXXtl7PUMUrIexaefOtXILL/vw1a9+tbcflRRedqJYhkcQ4+fGEO4+zF3t95Og70xH5I/rs88+i7ffftvatejcFVeLwss54bkiXsrLL7+MSy65JOt7wvvy7RCV8HohmucaE0YYdhtBhZdfPvaFu/Sci2TcCMC8wdxUqHzhCi5wMfWNXpYp4Z07d67l7b755pu9M8gtwjNmzLAO/6kEX3bkscceA9PactMDA5oi8u3KCyNBX8J7h/Wj5twG7neOCm1wkfD6Jbn5+rC/tPm6ka8N5iQysTtIoRE5NzF42UBhGw5jg7nbo/Mlo+dL37GvYzpa7lkNfjxePjJ7OcCEfWAOLw+s4VODszhXyFkfnx6cm0pyF138cPbyw2bXx7n9+c9/bu1e8nLoi1s/mF74ne98p/dH0PnFZmiBu6a6urrArAGvu+YkvKUJb7FtyhJeN4su8HmlhDdgd/Pe5kd4Gecr5MlyG6y9MJRvS6ktCox/lSK8pXpxueEReu/MuqAHahfnBgu/rP0Ir103RfCDDz7wLIb8UWFaGh9pned15MYRyYrhgtwNNryf/846+CTz+uuv590NSbFmuIgbUOy5NWHzuTY2ZswYK+c26M4+ci4lxhvU4yU/OjlcB8m3OaaQ8LKvXkMbtg1xzYVxei+bqPzatNv1VRnjzWfobiD8fO5XeAvFbu30Mp6Ryp1Zzlgwt2by6ENuEvDyBWD/CxllKcLL1C3mbjq3bbItPkZSMO3C/jJdb/jw4X5QWtcGEV7fjWy+gZtCzj333N5Fw9zcVOZ/MxPA7ctIIebWas4ZY5Rcgd93332tdMFyn+aWb+z51hhKPX0t35NN7ql4hebOr/DSzngUKU/cK7bFXelkAS3fxK9/1ISXqJiaxMdzZ4K7LeDXX3991gEwudkPlRJeHgvIL1Cu6HI8uVkPthjni127mYpJ4TVhf7njNdEmz0ZmHJ52ZhfOHdOtgpZcMadd8keY7dil0Nzxc9sD5SYmHgnAH6jcQrHlUZ9ezxOR8AacTRNGGEXhJa7c/FwaMjd50PN9//33e4nmetQmhZd92nbbba3t1scdd1zBIy25yYOf8wB7uzBdiwes0Hv3c4aChDfgl8lxGw/359kV3EptF/5gMmZf7GCcQi3To2eoixk1dskXvvA6dzynmqLpDE/Z9XKH6WWXXWZlg7gVCa8boQKf5xPFUn+ZvXgYlVpccx60nS+kkNt3ihfP33VuyyxVeL0urvmNeeU+tnMsXBjh9uhvfvObnr/wXr+8AU0u67bcWHq+bbBhtOOsw4TNs73cFED+G7NimJPs50xohsb4feE5vM5snHzpXX7mjmsVfCLiiYG5C5X8nvCsZbdzJXJDXAcffDBuvfVWX+MLe36D1Gc8xptvYWbChAlWUruXX7xCgxw7dmzv2x7C9qq9GJfXGNv999+/RXqZc0zcpsvQg3M3VqnCG8QwvNxT7HBy/oDw9LcjjzzS2vFVrHDByrnLMNfj52IYt0+zvVIKd8BRUIotrpVSf6F7Tdg82+YjPcNZuY/0DBkxc4NHrxZ7pxr5ctGQcVx6zrlHg+bb8u7lu+HkwjZ4tjMX0HLFlzrAfHt7w1A+nrlHAdDOuLBb7B63OWVMnjbn58fJrU63z40Lb6FfZreOun3u3DoYZeEtdupYoTNPoyq8nBOGHOjh8hUwYZVc4fWyHTto27npZEHrcbsvnzfqdo/b5/m2y7r9sLvVme9zPgnR06RzlBtC8iu8rJ8eNXPCyT73ECg6X9w5yO31+Uqho16DjMu+pxI72CoivIV+mUuB11eEl2MsJCSFRCDKwsvx8BHyW9/6lnXuq9dc12JzbUp4822gKMUGi91bbpu32y4UJihlXDxAnXna+c7ECCK8dl8KvaKIXizDHMw+yRX6crxRpmaEl+D52McJdb5VoBTj6EvCmy+9jAtajD8yZJJboi68thfz+OOP4+tf/3rJc5obSyyHx3v44YeDedR+DggvxT7LbfPOvtG++AZt5hLnboTxMwYKIOeTb+oodBBRKcJrM+F315ntw38v9sJLPjXSA+e5J2H80NeU8BIud1MxV5Ur4YUS0r0aSl8SXo6JWQzMCuC23GLvtOK1fUF4nR4XNxpwwYOvkeEXys8OM+70Y4zbeapWWMLL1X3GnfmSUK9vH/Fqf16vK5fN52ufTyJ8Ky8Fypk149ZXxoH5feIJeW5pXqUKL/vCVDhuiXfuhLT7yHQzetvt7e1Z3bZfXc8dlYz/+7Gx3PHXnPC6GUC1f84UIJ44xokPsvGg2vlofOERoDBx7aOYg8Ot6bRF/kD5SQcMr5e1U1NFYry1g1cjFQEREIEtCUh4ZRUiIAIiYJiAhNcwcDUnAiIgAhJe2YAIiIAIGCYg4TUMXM2JgAiIgIRXNiACIiAChglIeA0DV3MiIAIiIOGVDYiACIiAYQISXsPA1ZwIiIAISHhlAyIgAiJgmICE1zBwNScCIiACEl7ZgAiIgAgYJiDhNQxczYmACIiAhFc2IAIiIAKGCUh4DQNXcyIgAiIg4ZUNiIAIiIBhAhJew8DVnAiIgAhIeGUDIiACImCYgITXMHA1JwIiIAISXtmACIiACBgmIOE1DFzNiYAIiICEVzYgAiIgAoYJSHgNA1dzIiACIiDhlQ2IgAiIgGECEl7DwNWcCIiACEh4ZQMiIAIiYJiAhNcwcDUnAiIgAhJe2YAIiIAIGCYg4TUMXM2JgAiIgIRXNiACIiAChglIeA0DV3MiIAIiIOGVDYiACIiAYQISXsPA1ZwIiIAISHhlAyIgAiJgmICE1zBwNScCIiACEl7ZgAiIgAgYJiDhNQxczYmACIiAhFc2IAIiIAKGCUh4DQNXcyIgAiIg4ZUNiIAIiIBhAhJew8DVnAiIgAhIeGUDIiACImCYgITXMHA1JwIiIAISXtmACIiACBgmIOE1DFzNiYAIiICEVzYgAiIgAoYJSHgNA1dzIiACIiDhlQ2IgAiIgGECEl7DwNWcCIiACEh4ZQMiIAIiYJiAhNcwcDUnAiIgAhJe2YAIiIAIGCYg4TUMXM2JgAiIgIRXNiACIiAChglIeA0DV3MiIAIiIOGVDYiACIiAYQISXsPA1ZwIiIAISHhlAyIgAiJgmICE1zBwNScCIiACEl7ZgAiIgAgYJiDhNQxczYmACIiAhFc2IAIiIAKGCUh4DQNXcyIgAiIg4ZUNiIAIiIBhAhJew8DVnAiIgAhIeGUDIiACImCYgITXMHA1JwIiIAISXtmACIiACBgmIOE1DFzNiYAIiICEVzYgAiIgAoYJSHgNA1dzIiACIiDhlQ2IgAiIgGECEl7DwNWcCIiACEh4ZQMiIAIiYJiAhNcwcDUnAiIgAhJe2YAIiIAIGCYg4TUMXM2JgAiIgIRXNiACIiAChglIeA0DV3MiIAIiIOGVDYiACIiAYQISXsPA1ZwIiIAISHhlAyIgAiJgmICE1zBwNScCIiACEl7ZgAiIgAgYJiDhNQxczYmACIiAhFc2IAIiIAKGCUh4DQNXcyIgAiIg4ZUNiIAIiIBhAhJew8DVnAiIgAhIeGUDIiACImCYgITXMHA1JwIiIAISXtmACIiACBgmIOE1DFzNiYAIiICEVzYgAiIgAoYJSHgNA1dzIiACIiDhlQ2IgAiIgGECEl7DwNWcCIiACEh4ZQMiIAIiYJiAhNcwcDUnAiIgAhJe2YAIiIAIGCYg4TUMXM2JgAiIgIRXNiACIiAChglIeA0DV3MiIAIiIOGVDYiACIiAYQL/By8I06msTvMLAAAAAElFTkSuQmCC',
  link1: undefined,
  privacyLink: undefined,
  link4: undefined,
  termsLink: undefined,
  logoAlt: 'University Campus Registration System',
}

Footer51.propTypes = {
  link5: PropTypes.element,
  action1: PropTypes.element,
  content1: PropTypes.element,
  logoSrc: PropTypes.string,
  link1: PropTypes.element,
  privacyLink: PropTypes.element,
  link4: PropTypes.element,
  termsLink: PropTypes.element,
  logoAlt: PropTypes.string,
}

export default Footer51
