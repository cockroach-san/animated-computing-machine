import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { Auth0Provider } from "@auth0/auth0-react";
import Navbar from './CampusCore/src/components/navbar';
import './CampusCore/src/style.css';
import Home from './CampusCore/src/views/home';
import NotFound from './CampusCore/src/views/not-found';
import RegistrationForm from './CampusCore/src/components/RegistrationForm';
import Event from './CampusCore/src/components/Event';
import About from './CampusCore/src/components/about';
import User from './CampusCore/Backend/models/User';
import Profile from './CampusCore/src/components/profile';
import AuthForm from './CampusCore/src/components/AuthForm';
import ForgotPassword from './CampusCore/src/components/forgotpassword';

const App = () => {
  const [isSignup, setIsSignup] = useState(false); // Add state for signup

  return (
    <Auth0Provider domain={process.env.REACT_APP_AUTH0_DOMAIN}
      clientId={process.env.REACT_APP_AUTH0_CLIENT_ID}
      authorizationParams={{ redirect_uri: window.location.origin }}>
      
      <Router>
        <Navbar setIsSignup={setIsSignup} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/registration" element={<RegistrationForm />} />
          <Route path="/register" element={<AuthForm isSignup={true} />} /> {/* Ensure signup mode */}
          <Route path="/login" element={<AuthForm isSignup={false} />} />
          <Route path="/event" element={<Event />} />
          <Route path="/forgotpassword" element={<ForgotPassword />} />
          <Route path="/about" element={<About />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/user" element={<User />} />
          <Route path="/redirect-to-login" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </Auth0Provider>
  );
};

export default App;
