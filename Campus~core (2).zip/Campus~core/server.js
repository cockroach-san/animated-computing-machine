require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const argon2 = require("argon2");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 5000;

// =======================
// Middleware
// =======================
app.use(express.json());
app.use(cors());

// Catch JSON parsing errors
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError) {
    return res.status(400).json({ error: "Invalid JSON format." });
  }
  next();
});

// =======================
// MongoDB Connection with Retry Logic
// =======================
const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
      throw new Error("MONGO_URI is missing in the environment variables.");
    }
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log("✅ MongoDB Connected Successfully");
  } catch (err) {
    console.error("❌ MongoDB Connection Error:", err.message);
    setTimeout(connectDB, 5000); // Retry connection after 5 seconds
  }
};
connectDB();

// =======================
// Models & Schemas
// =======================

// Registration Schema for event registration
const registrationSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true },
    rollNo: { type: String, required: true },
    gender: { type: String },
    department: { type: String },
    event: { type: String, required: true },
    date: { type: String, required: true },
    time: { type: String, required: true },
    venue: { type: String, required: true },
    preference: { type: String },
    // The userId is kept optional; if you need to link a registration to a user later,
    // an authenticated endpoint could assign that.
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  },
  { timestamps: true }
);
const Registration = mongoose.model("Registration", registrationSchema);

// User Schema for authentication (Updated with required username)
const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true }, // Username is now required and unique
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true },
    // Fields for password reset functionality
    resetToken: { type: String, default: null },
    resetTokenExpires: { type: Date, default: null }
  },
  { timestamps: true }
);
const User = mongoose.model("User", userSchema);

// =======================
// Authentication Middleware
// (Remains for authentication endpoints only)
// =======================
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(" ")[1]; // Still expecting "Bearer <token>"

  if (!token) return res.status(401).json({ message: "Unauthorized: Token missing" });

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ message: "Invalid token" });
    req.user = decoded;
    next();
  });
};

// =======================
// Registration Endpoints (Public for Event Registration)
// =======================

// POST /api/registration
// Public endpoint: Creates a new event registration entry (no auth required)
app.post("/api/registration", async (req, res) => {
  try {
    const { fullName, rollNo, event, date, time, venue } = req.body;
    // Validate required fields for event registration
    if (!fullName || !rollNo || !event || !date || !time || !venue) {
      return res.status(400).json({ error: "Missing required fields." });
    }
    const registrationData = new Registration(req.body);
    await registrationData.save();
    res.status(201).json({ message: "Registration successful!", data: registrationData });
  } catch (error) {
    console.error("Error saving registration:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// GET /api/registration
// Public endpoint: Retrieves all event registrations
app.get("/api/registration", async (req, res) => {
  try {
    const registrations = await Registration.find();
    res.status(200).json(registrations);
  } catch (error) {
    console.error("Error retrieving registrations:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// =======================
// Authentication Endpoints (Protected)
// =======================

// POST /api/auth/register
// Registers a new user by requiring username, email, and password, then generates a JWT token.
app.post("/api/auth/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    // Validate that all required fields are provided
    if (!username || !email || !password) {
      return res.status(400).json({ error: "Username, email, and password are required." });
    }
    
    // Check if a user with the provided email already exists
    let existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "A user with that email already exists." });
    }
    
    // Check if a user with the provided username already exists
    existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ error: "Username is already taken." });
    }
    
    // Hash the provided password using Argon2 for security
    const hashedPassword = await argon2.hash(password);
    
    // Create a new user including the username
    const newUser = new User({ username, email, password: hashedPassword });
    await newUser.save();
    
    // Generate a JWT token for the new user
    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    
    res.status(201).json({ message: "Signup successful", token });
  } catch (error) {
    console.error("Error during signup:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// POST /api/auth/login
// Authenticates a user based on their email and password and returns a JWT token.
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: "Email and password are required." });

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error: "User not found" });

    const validPassword = await argon2.verify(user.password, password);
    if (!validPassword) return res.status(401).json({ error: "Invalid credentials" });

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.status(200).json({ message: "Login successful", token });
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// =======================
// Graceful Shutdown
// =======================
process.on("SIGINT", async () => {
  await mongoose.connection.close();
  console.log("🔻 MongoDB disconnected. Server shutting down.");
  process.exit(0);
});

// =======================
// Start the Server
// =======================
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
